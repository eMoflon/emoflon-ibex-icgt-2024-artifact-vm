package refactoringcd.full.api;
		
import refactoringcd.full.api.pattern.MethodsWithCommonAttributePattern;
import refactoringcd.full.api.pattern.MoveLastCommonAttributeToOtherClassPattern;
import refactoringcd.full.api.pattern.IntactMethodAttributeDependencyPattern;
import org.emoflon.ibex.gt.engine.IBeXGTPatternFactory;
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import refactoringcd.full.api.pattern.MethodsWithCommonAttribute4Pattern;
import refactoringcd.full.api.pattern.MethodsWithCommonAttribute3Pattern;
import refactoringcd.full.api.pattern.MovingMethodToOtherMethodWithoutCommonDependencyPattern;
import refactoringcd.full.api.pattern.MoveFirstCommonAttributeToOtherClassPattern;
import refactoringcd.full.api.pattern.MovingMethodToOtherMethodWithCommonDependencyPattern;
import refactoringcd.full.api.pattern.MethodsWithCommonAttribute2WithAnotherCommonAttributePattern;
import refactoringcd.full.api.pattern.MovingMethodWithAttributeDependencyTogetherPattern;
import refactoringcd.full.api.pattern.MethodsWithCommonAttribute2Pattern;
import refactoringcd.full.api.pattern.MethodsWithOtherCommonAttribute4Pattern;
		
public class FullGtPatternFactory extends IBeXGTPatternFactory {	
	
	public FullGtPatternFactory(IBeXGtAPI<?, ?, ?> api) {
			super(api);
	}
	
	protected IntactMethodAttributeDependencyPattern createIntactMethodAttributeDependencyPattern() {
		IntactMethodAttributeDependencyPattern pattern = new IntactMethodAttributeDependencyPattern(api, api.getGTEngine().getPattern("intactMethodAttributeDependency"));
		return pattern;
	}
	
	protected MethodsWithCommonAttributePattern createMethodsWithCommonAttributePattern() {
		MethodsWithCommonAttributePattern pattern = new MethodsWithCommonAttributePattern(api, api.getGTEngine().getPattern("methodsWithCommonAttribute"));
		return pattern;
	}
	
	protected MethodsWithCommonAttribute2Pattern createMethodsWithCommonAttribute2Pattern() {
		MethodsWithCommonAttribute2Pattern pattern = new MethodsWithCommonAttribute2Pattern(api, api.getGTEngine().getPattern("methodsWithCommonAttribute2"));
		return pattern;
	}
	
	protected MethodsWithCommonAttribute2WithAnotherCommonAttributePattern createMethodsWithCommonAttribute2WithAnotherCommonAttributePattern() {
		MethodsWithCommonAttribute2WithAnotherCommonAttributePattern pattern = new MethodsWithCommonAttribute2WithAnotherCommonAttributePattern(api, api.getGTEngine().getPattern("methodsWithCommonAttribute2WithAnotherCommonAttribute"));
		return pattern;
	}
	
	protected MethodsWithCommonAttribute3Pattern createMethodsWithCommonAttribute3Pattern() {
		MethodsWithCommonAttribute3Pattern pattern = new MethodsWithCommonAttribute3Pattern(api, api.getGTEngine().getPattern("methodsWithCommonAttribute3"));
		return pattern;
	}
	
	protected MethodsWithCommonAttribute4Pattern createMethodsWithCommonAttribute4Pattern() {
		MethodsWithCommonAttribute4Pattern pattern = new MethodsWithCommonAttribute4Pattern(api, api.getGTEngine().getPattern("methodsWithCommonAttribute4"));
		return pattern;
	}
	
	protected MethodsWithOtherCommonAttribute4Pattern createMethodsWithOtherCommonAttribute4Pattern() {
		MethodsWithOtherCommonAttribute4Pattern pattern = new MethodsWithOtherCommonAttribute4Pattern(api, api.getGTEngine().getPattern("methodsWithOtherCommonAttribute4"));
		return pattern;
	}
	
	protected MoveFirstCommonAttributeToOtherClassPattern createMoveFirstCommonAttributeToOtherClassPattern() {
		MoveFirstCommonAttributeToOtherClassPattern pattern = new MoveFirstCommonAttributeToOtherClassPattern(api, api.getGTEngine().getPattern("moveFirstCommonAttributeToOtherClass"));
		return pattern;
	}
	
	protected MoveLastCommonAttributeToOtherClassPattern createMoveLastCommonAttributeToOtherClassPattern() {
		MoveLastCommonAttributeToOtherClassPattern pattern = new MoveLastCommonAttributeToOtherClassPattern(api, api.getGTEngine().getPattern("moveLastCommonAttributeToOtherClass"));
		return pattern;
	}
	
	protected MovingMethodToOtherMethodWithCommonDependencyPattern createMovingMethodToOtherMethodWithCommonDependencyPattern() {
		MovingMethodToOtherMethodWithCommonDependencyPattern pattern = new MovingMethodToOtherMethodWithCommonDependencyPattern(api, api.getGTEngine().getPattern("movingMethodToOtherMethodWithCommonDependency"));
		return pattern;
	}
	
	protected MovingMethodToOtherMethodWithoutCommonDependencyPattern createMovingMethodToOtherMethodWithoutCommonDependencyPattern() {
		MovingMethodToOtherMethodWithoutCommonDependencyPattern pattern = new MovingMethodToOtherMethodWithoutCommonDependencyPattern(api, api.getGTEngine().getPattern("movingMethodToOtherMethodWithoutCommonDependency"));
		return pattern;
	}
	
	protected MovingMethodWithAttributeDependencyTogetherPattern createMovingMethodWithAttributeDependencyTogetherPattern() {
		MovingMethodWithAttributeDependencyTogetherPattern pattern = new MovingMethodWithAttributeDependencyTogetherPattern(api, api.getGTEngine().getPattern("movingMethodWithAttributeDependencyTogether"));
		return pattern;
	}
	
}