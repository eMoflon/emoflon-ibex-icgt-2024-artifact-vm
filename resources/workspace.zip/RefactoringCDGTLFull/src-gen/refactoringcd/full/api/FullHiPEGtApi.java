package refactoringcd.full.api;
		
import org.emoflon.ibex.gt.engine.hipe.HiPEPatternMatchingEngine;
import org.eclipse.emf.ecore.resource.ResourceSet;

public class FullHiPEGtApi extends FullGtApi<HiPEPatternMatchingEngine> {
	
	@Override
	protected HiPEPatternMatchingEngine createPatternMatcher() {
		return new HiPEPatternMatchingEngine(ibexModel, model);
	}
}
