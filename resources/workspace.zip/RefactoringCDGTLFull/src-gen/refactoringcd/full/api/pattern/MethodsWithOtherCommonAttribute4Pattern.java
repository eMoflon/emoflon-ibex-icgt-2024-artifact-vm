package refactoringcd.full.api.pattern;
		
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import java.util.List;
import classDiagram.Attribute;
import refactoringcd.full.api.match.MethodsWithOtherCommonAttribute4Match;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import org.eclipse.emf.ecore.EObject;
import org.emoflon.ibex.gt.gtmodel.IBeXGTModel.GTPattern;
import classDiagram.Clazz;
import org.emoflon.ibex.gt.engine.IBeXGTPattern;
import classDiagram.Method;

public class MethodsWithOtherCommonAttribute4Pattern extends IBeXGTPattern<MethodsWithOtherCommonAttribute4Pattern, MethodsWithOtherCommonAttribute4Match> {
	
	
	
	protected Clazz fromClazzBinding = null;
	protected Clazz toClazzBinding = null;
	protected Method fromMethodBinding = null;
	protected Method toMethodBinding = null;
	protected Attribute commonAttributeBinding = null;
	protected Attribute otherAttributeBinding = null;
	
	public MethodsWithOtherCommonAttribute4Pattern(final IBeXGtAPI<?, ?, ?> api, final GTPattern pattern) {
		super(api, pattern);
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of();
	}
	
	@Override
	public Map<String, Object> getParameters() {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	@Override
	public MethodsWithOtherCommonAttribute4Pattern setParameters(final Map<String, Object> parameters) {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	
	public MethodsWithOtherCommonAttribute4Pattern bindFromClazz(final Clazz fromClazz) {
		this.fromClazzBinding = fromClazz;
		setBinding("fromClazz", fromClazz);
		return this;
	}
	
	public MethodsWithOtherCommonAttribute4Pattern unbindFromClazz() {
		this.fromClazzBinding = null;
		unsetBinding("fromClazz");
		return this;
	}
	
	public MethodsWithOtherCommonAttribute4Pattern bindToClazz(final Clazz toClazz) {
		this.toClazzBinding = toClazz;
		setBinding("toClazz", toClazz);
		return this;
	}
	
	public MethodsWithOtherCommonAttribute4Pattern unbindToClazz() {
		this.toClazzBinding = null;
		unsetBinding("toClazz");
		return this;
	}
	
	public MethodsWithOtherCommonAttribute4Pattern bindFromMethod(final Method fromMethod) {
		this.fromMethodBinding = fromMethod;
		setBinding("fromMethod", fromMethod);
		return this;
	}
	
	public MethodsWithOtherCommonAttribute4Pattern unbindFromMethod() {
		this.fromMethodBinding = null;
		unsetBinding("fromMethod");
		return this;
	}
	
	public MethodsWithOtherCommonAttribute4Pattern bindToMethod(final Method toMethod) {
		this.toMethodBinding = toMethod;
		setBinding("toMethod", toMethod);
		return this;
	}
	
	public MethodsWithOtherCommonAttribute4Pattern unbindToMethod() {
		this.toMethodBinding = null;
		unsetBinding("toMethod");
		return this;
	}
	
	public MethodsWithOtherCommonAttribute4Pattern bindCommonAttribute(final Attribute commonAttribute) {
		this.commonAttributeBinding = commonAttribute;
		setBinding("commonAttribute", commonAttribute);
		return this;
	}
	
	public MethodsWithOtherCommonAttribute4Pattern unbindCommonAttribute() {
		this.commonAttributeBinding = null;
		unsetBinding("commonAttribute");
		return this;
	}
	
	public MethodsWithOtherCommonAttribute4Pattern bindOtherAttribute(final Attribute otherAttribute) {
		this.otherAttributeBinding = otherAttribute;
		setBinding("otherAttribute", otherAttribute);
		return this;
	}
	
	public MethodsWithOtherCommonAttribute4Pattern unbindOtherAttribute() {
		this.otherAttributeBinding = null;
		unsetBinding("otherAttribute");
		return this;
	}
	
	
	@Override
	public boolean checkBindings(final MethodsWithOtherCommonAttribute4Match match) {
		if(bindings.isEmpty())
			return true;
			
		boolean bound = true;
		bound &= fromClazzBinding == null || match.fromClazz().equals(fromClazzBinding);
		bound &= toClazzBinding == null || match.toClazz().equals(toClazzBinding);
		bound &= fromMethodBinding == null || match.fromMethod().equals(fromMethodBinding);
		bound &= toMethodBinding == null || match.toMethod().equals(toMethodBinding);
		bound &= commonAttributeBinding == null || match.commonAttribute().equals(commonAttributeBinding);
		bound &= otherAttributeBinding == null || match.otherAttribute().equals(otherAttributeBinding);
		return bound;
	}
	
	@Override
	public boolean checkConditions(final MethodsWithOtherCommonAttribute4Match match) {
		return (!(match.fromMethod()).equals(match.toMethod())) && 
		(!(match.fromClazz()).equals(match.toClazz())) && 
		(!(match.commonAttribute()).equals(match.otherAttribute()));
	}
	
	@Override
	public boolean hasArithmeticExpressions() {
		return false;
	}
	
	@Override
	public boolean hasBooleanExpressions() {
		return false;
	}
	
	@Override
	public boolean hasCountExpressions() {
		return false;
	}
	
	@Override
	public boolean hasParameterExpressions() {
		return false;
	}
	
	public MethodsWithOtherCommonAttribute4Match createMatch(final Map<String, Object> nodes,  Object... args) {
		return new MethodsWithOtherCommonAttribute4Match(this, nodes);
	}
	
	@Override
	protected Set<EObject> insertNodesAndMatch(final MethodsWithOtherCommonAttribute4Match match) {
		throw new UnsupportedOperationException("The pattern <methodsWithOtherCommonAttribute4> does not define any attributes to watch.");
	}
}
