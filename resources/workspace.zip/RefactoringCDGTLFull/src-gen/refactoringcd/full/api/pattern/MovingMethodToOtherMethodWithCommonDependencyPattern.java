package refactoringcd.full.api.pattern;
		
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import java.util.List;
import refactoringcd.full.api.match.MovingMethodToOtherMethodWithCommonDependencyMatch;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import org.eclipse.emf.ecore.EObject;
import org.emoflon.ibex.gt.gtmodel.IBeXGTModel.GTPattern;
import classDiagram.Clazz;
import org.emoflon.ibex.gt.engine.IBeXGTPattern;
import classDiagram.Method;

public class MovingMethodToOtherMethodWithCommonDependencyPattern extends IBeXGTPattern<MovingMethodToOtherMethodWithCommonDependencyPattern, MovingMethodToOtherMethodWithCommonDependencyMatch> {
	
	
	
	protected Clazz fromClazzBinding = null;
	protected Clazz toClazzBinding = null;
	protected Method fromMethodBinding = null;
	protected Method toMethodBinding = null;
	
	public MovingMethodToOtherMethodWithCommonDependencyPattern(final IBeXGtAPI<?, ?, ?> api, final GTPattern pattern) {
		super(api, pattern);
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of();
	}
	
	@Override
	public Map<String, Object> getParameters() {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	@Override
	public MovingMethodToOtherMethodWithCommonDependencyPattern setParameters(final Map<String, Object> parameters) {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	
	public MovingMethodToOtherMethodWithCommonDependencyPattern bindFromClazz(final Clazz fromClazz) {
		this.fromClazzBinding = fromClazz;
		setBinding("fromClazz", fromClazz);
		return this;
	}
	
	public MovingMethodToOtherMethodWithCommonDependencyPattern unbindFromClazz() {
		this.fromClazzBinding = null;
		unsetBinding("fromClazz");
		return this;
	}
	
	public MovingMethodToOtherMethodWithCommonDependencyPattern bindToClazz(final Clazz toClazz) {
		this.toClazzBinding = toClazz;
		setBinding("toClazz", toClazz);
		return this;
	}
	
	public MovingMethodToOtherMethodWithCommonDependencyPattern unbindToClazz() {
		this.toClazzBinding = null;
		unsetBinding("toClazz");
		return this;
	}
	
	public MovingMethodToOtherMethodWithCommonDependencyPattern bindFromMethod(final Method fromMethod) {
		this.fromMethodBinding = fromMethod;
		setBinding("fromMethod", fromMethod);
		return this;
	}
	
	public MovingMethodToOtherMethodWithCommonDependencyPattern unbindFromMethod() {
		this.fromMethodBinding = null;
		unsetBinding("fromMethod");
		return this;
	}
	
	public MovingMethodToOtherMethodWithCommonDependencyPattern bindToMethod(final Method toMethod) {
		this.toMethodBinding = toMethod;
		setBinding("toMethod", toMethod);
		return this;
	}
	
	public MovingMethodToOtherMethodWithCommonDependencyPattern unbindToMethod() {
		this.toMethodBinding = null;
		unsetBinding("toMethod");
		return this;
	}
	
	
	@Override
	public boolean checkBindings(final MovingMethodToOtherMethodWithCommonDependencyMatch match) {
		if(bindings.isEmpty())
			return true;
			
		boolean bound = true;
		bound &= fromClazzBinding == null || match.fromClazz().equals(fromClazzBinding);
		bound &= toClazzBinding == null || match.toClazz().equals(toClazzBinding);
		bound &= fromMethodBinding == null || match.fromMethod().equals(fromMethodBinding);
		bound &= toMethodBinding == null || match.toMethod().equals(toMethodBinding);
		return bound;
	}
	
	@Override
	public boolean checkConditions(final MovingMethodToOtherMethodWithCommonDependencyMatch match) {
		return (!(match.fromMethod()).equals(match.toMethod())) && 
		(!(match.fromClazz()).equals(match.toClazz()));
	}
	
	@Override
	public boolean hasArithmeticExpressions() {
		return false;
	}
	
	@Override
	public boolean hasBooleanExpressions() {
		return false;
	}
	
	@Override
	public boolean hasCountExpressions() {
		return false;
	}
	
	@Override
	public boolean hasParameterExpressions() {
		return false;
	}
	
	public MovingMethodToOtherMethodWithCommonDependencyMatch createMatch(final Map<String, Object> nodes,  Object... args) {
		return new MovingMethodToOtherMethodWithCommonDependencyMatch(this, nodes);
	}
	
	@Override
	protected Set<EObject> insertNodesAndMatch(final MovingMethodToOtherMethodWithCommonDependencyMatch match) {
		throw new UnsupportedOperationException("The pattern <movingMethodToOtherMethodWithCommonDependency> does not define any attributes to watch.");
	}
}
