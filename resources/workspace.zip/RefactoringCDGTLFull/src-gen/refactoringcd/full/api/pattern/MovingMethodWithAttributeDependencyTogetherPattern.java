package refactoringcd.full.api.pattern;
		
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import java.util.List;
import refactoringcd.full.api.match.MovingMethodWithAttributeDependencyTogetherMatch;
import classDiagram.Attribute;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import org.eclipse.emf.ecore.EObject;
import org.emoflon.ibex.gt.gtmodel.IBeXGTModel.GTPattern;
import classDiagram.Clazz;
import org.emoflon.ibex.gt.engine.IBeXGTPattern;
import classDiagram.Method;

public class MovingMethodWithAttributeDependencyTogetherPattern extends IBeXGTPattern<MovingMethodWithAttributeDependencyTogetherPattern, MovingMethodWithAttributeDependencyTogetherMatch> {
	
	
	
	protected Clazz fromClazzBinding = null;
	protected Clazz toClazzBinding = null;
	protected Method methodBinding = null;
	protected Attribute attributeBinding = null;
	
	public MovingMethodWithAttributeDependencyTogetherPattern(final IBeXGtAPI<?, ?, ?> api, final GTPattern pattern) {
		super(api, pattern);
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of();
	}
	
	@Override
	public Map<String, Object> getParameters() {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	@Override
	public MovingMethodWithAttributeDependencyTogetherPattern setParameters(final Map<String, Object> parameters) {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	
	public MovingMethodWithAttributeDependencyTogetherPattern bindFromClazz(final Clazz fromClazz) {
		this.fromClazzBinding = fromClazz;
		setBinding("fromClazz", fromClazz);
		return this;
	}
	
	public MovingMethodWithAttributeDependencyTogetherPattern unbindFromClazz() {
		this.fromClazzBinding = null;
		unsetBinding("fromClazz");
		return this;
	}
	
	public MovingMethodWithAttributeDependencyTogetherPattern bindToClazz(final Clazz toClazz) {
		this.toClazzBinding = toClazz;
		setBinding("toClazz", toClazz);
		return this;
	}
	
	public MovingMethodWithAttributeDependencyTogetherPattern unbindToClazz() {
		this.toClazzBinding = null;
		unsetBinding("toClazz");
		return this;
	}
	
	public MovingMethodWithAttributeDependencyTogetherPattern bindMethod(final Method method) {
		this.methodBinding = method;
		setBinding("method", method);
		return this;
	}
	
	public MovingMethodWithAttributeDependencyTogetherPattern unbindMethod() {
		this.methodBinding = null;
		unsetBinding("method");
		return this;
	}
	
	public MovingMethodWithAttributeDependencyTogetherPattern bindAttribute(final Attribute attribute) {
		this.attributeBinding = attribute;
		setBinding("attribute", attribute);
		return this;
	}
	
	public MovingMethodWithAttributeDependencyTogetherPattern unbindAttribute() {
		this.attributeBinding = null;
		unsetBinding("attribute");
		return this;
	}
	
	
	@Override
	public boolean checkBindings(final MovingMethodWithAttributeDependencyTogetherMatch match) {
		if(bindings.isEmpty())
			return true;
			
		boolean bound = true;
		bound &= fromClazzBinding == null || match.fromClazz().equals(fromClazzBinding);
		bound &= toClazzBinding == null || match.toClazz().equals(toClazzBinding);
		bound &= methodBinding == null || match.method().equals(methodBinding);
		bound &= attributeBinding == null || match.attribute().equals(attributeBinding);
		return bound;
	}
	
	@Override
	public boolean checkConditions(final MovingMethodWithAttributeDependencyTogetherMatch match) {
		return (!(match.fromClazz()).equals(match.toClazz()));
	}
	
	@Override
	public boolean hasArithmeticExpressions() {
		return false;
	}
	
	@Override
	public boolean hasBooleanExpressions() {
		return false;
	}
	
	@Override
	public boolean hasCountExpressions() {
		return false;
	}
	
	@Override
	public boolean hasParameterExpressions() {
		return false;
	}
	
	public MovingMethodWithAttributeDependencyTogetherMatch createMatch(final Map<String, Object> nodes,  Object... args) {
		return new MovingMethodWithAttributeDependencyTogetherMatch(this, nodes);
	}
	
	@Override
	protected Set<EObject> insertNodesAndMatch(final MovingMethodWithAttributeDependencyTogetherMatch match) {
		throw new UnsupportedOperationException("The pattern <movingMethodWithAttributeDependencyTogether> does not define any attributes to watch.");
	}
}
