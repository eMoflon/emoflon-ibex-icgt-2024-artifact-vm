package refactoringcd.full.api.pattern;
		
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import java.util.List;
import classDiagram.Attribute;
import java.util.Collection;
import java.util.Map;
import refactoringcd.full.api.match.MoveFirstCommonAttributeToOtherClassMatch;
import java.util.Set;
import org.eclipse.emf.ecore.EObject;
import org.emoflon.ibex.gt.gtmodel.IBeXGTModel.GTPattern;
import classDiagram.Clazz;
import org.emoflon.ibex.gt.engine.IBeXGTPattern;
import classDiagram.Method;

public class MoveFirstCommonAttributeToOtherClassPattern extends IBeXGTPattern<MoveFirstCommonAttributeToOtherClassPattern, MoveFirstCommonAttributeToOtherClassMatch> {
	
	
	
	protected Clazz fromClazzBinding = null;
	protected Clazz toClazzBinding = null;
	protected Method fromMethodBinding = null;
	protected Method toMethodBinding = null;
	protected Attribute attributeBinding = null;
	
	public MoveFirstCommonAttributeToOtherClassPattern(final IBeXGtAPI<?, ?, ?> api, final GTPattern pattern) {
		super(api, pattern);
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of();
	}
	
	@Override
	public Map<String, Object> getParameters() {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	@Override
	public MoveFirstCommonAttributeToOtherClassPattern setParameters(final Map<String, Object> parameters) {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	
	public MoveFirstCommonAttributeToOtherClassPattern bindFromClazz(final Clazz fromClazz) {
		this.fromClazzBinding = fromClazz;
		setBinding("fromClazz", fromClazz);
		return this;
	}
	
	public MoveFirstCommonAttributeToOtherClassPattern unbindFromClazz() {
		this.fromClazzBinding = null;
		unsetBinding("fromClazz");
		return this;
	}
	
	public MoveFirstCommonAttributeToOtherClassPattern bindToClazz(final Clazz toClazz) {
		this.toClazzBinding = toClazz;
		setBinding("toClazz", toClazz);
		return this;
	}
	
	public MoveFirstCommonAttributeToOtherClassPattern unbindToClazz() {
		this.toClazzBinding = null;
		unsetBinding("toClazz");
		return this;
	}
	
	public MoveFirstCommonAttributeToOtherClassPattern bindFromMethod(final Method fromMethod) {
		this.fromMethodBinding = fromMethod;
		setBinding("fromMethod", fromMethod);
		return this;
	}
	
	public MoveFirstCommonAttributeToOtherClassPattern unbindFromMethod() {
		this.fromMethodBinding = null;
		unsetBinding("fromMethod");
		return this;
	}
	
	public MoveFirstCommonAttributeToOtherClassPattern bindToMethod(final Method toMethod) {
		this.toMethodBinding = toMethod;
		setBinding("toMethod", toMethod);
		return this;
	}
	
	public MoveFirstCommonAttributeToOtherClassPattern unbindToMethod() {
		this.toMethodBinding = null;
		unsetBinding("toMethod");
		return this;
	}
	
	public MoveFirstCommonAttributeToOtherClassPattern bindAttribute(final Attribute attribute) {
		this.attributeBinding = attribute;
		setBinding("attribute", attribute);
		return this;
	}
	
	public MoveFirstCommonAttributeToOtherClassPattern unbindAttribute() {
		this.attributeBinding = null;
		unsetBinding("attribute");
		return this;
	}
	
	
	@Override
	public boolean checkBindings(final MoveFirstCommonAttributeToOtherClassMatch match) {
		if(bindings.isEmpty())
			return true;
			
		boolean bound = true;
		bound &= fromClazzBinding == null || match.fromClazz().equals(fromClazzBinding);
		bound &= toClazzBinding == null || match.toClazz().equals(toClazzBinding);
		bound &= fromMethodBinding == null || match.fromMethod().equals(fromMethodBinding);
		bound &= toMethodBinding == null || match.toMethod().equals(toMethodBinding);
		bound &= attributeBinding == null || match.attribute().equals(attributeBinding);
		return bound;
	}
	
	@Override
	public boolean checkConditions(final MoveFirstCommonAttributeToOtherClassMatch match) {
		return (!(match.fromClazz()).equals(match.toClazz())) && 
		(!(match.toMethod()).equals(match.fromMethod()));
	}
	
	@Override
	public boolean hasArithmeticExpressions() {
		return false;
	}
	
	@Override
	public boolean hasBooleanExpressions() {
		return false;
	}
	
	@Override
	public boolean hasCountExpressions() {
		return false;
	}
	
	@Override
	public boolean hasParameterExpressions() {
		return false;
	}
	
	public MoveFirstCommonAttributeToOtherClassMatch createMatch(final Map<String, Object> nodes,  Object... args) {
		return new MoveFirstCommonAttributeToOtherClassMatch(this, nodes);
	}
	
	@Override
	protected Set<EObject> insertNodesAndMatch(final MoveFirstCommonAttributeToOtherClassMatch match) {
		throw new UnsupportedOperationException("The pattern <moveFirstCommonAttributeToOtherClass> does not define any attributes to watch.");
	}
}
