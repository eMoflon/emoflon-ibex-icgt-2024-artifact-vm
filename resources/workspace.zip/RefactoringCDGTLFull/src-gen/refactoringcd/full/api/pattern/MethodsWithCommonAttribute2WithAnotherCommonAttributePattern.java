package refactoringcd.full.api.pattern;
		
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import java.util.List;
import classDiagram.Attribute;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import org.eclipse.emf.ecore.EObject;
import org.emoflon.ibex.gt.gtmodel.IBeXGTModel.GTPattern;
import classDiagram.Clazz;
import org.emoflon.ibex.gt.engine.IBeXGTPattern;
import refactoringcd.full.api.match.MethodsWithCommonAttribute2WithAnotherCommonAttributeMatch;
import classDiagram.Method;

public class MethodsWithCommonAttribute2WithAnotherCommonAttributePattern extends IBeXGTPattern<MethodsWithCommonAttribute2WithAnotherCommonAttributePattern, MethodsWithCommonAttribute2WithAnotherCommonAttributeMatch> {
	
	
	
	protected Clazz fromClazzBinding = null;
	protected Clazz toClazzBinding = null;
	protected Method fromMethodBinding = null;
	protected Method toMethodBinding = null;
	protected Attribute commonAttributeBinding = null;
	protected Attribute otherAttributeBinding = null;
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern(final IBeXGtAPI<?, ?, ?> api, final GTPattern pattern) {
		super(api, pattern);
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of();
	}
	
	@Override
	public Map<String, Object> getParameters() {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	@Override
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern setParameters(final Map<String, Object> parameters) {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern bindFromClazz(final Clazz fromClazz) {
		this.fromClazzBinding = fromClazz;
		setBinding("fromClazz", fromClazz);
		return this;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern unbindFromClazz() {
		this.fromClazzBinding = null;
		unsetBinding("fromClazz");
		return this;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern bindToClazz(final Clazz toClazz) {
		this.toClazzBinding = toClazz;
		setBinding("toClazz", toClazz);
		return this;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern unbindToClazz() {
		this.toClazzBinding = null;
		unsetBinding("toClazz");
		return this;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern bindFromMethod(final Method fromMethod) {
		this.fromMethodBinding = fromMethod;
		setBinding("fromMethod", fromMethod);
		return this;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern unbindFromMethod() {
		this.fromMethodBinding = null;
		unsetBinding("fromMethod");
		return this;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern bindToMethod(final Method toMethod) {
		this.toMethodBinding = toMethod;
		setBinding("toMethod", toMethod);
		return this;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern unbindToMethod() {
		this.toMethodBinding = null;
		unsetBinding("toMethod");
		return this;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern bindCommonAttribute(final Attribute commonAttribute) {
		this.commonAttributeBinding = commonAttribute;
		setBinding("commonAttribute", commonAttribute);
		return this;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern unbindCommonAttribute() {
		this.commonAttributeBinding = null;
		unsetBinding("commonAttribute");
		return this;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern bindOtherAttribute(final Attribute otherAttribute) {
		this.otherAttributeBinding = otherAttribute;
		setBinding("otherAttribute", otherAttribute);
		return this;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern unbindOtherAttribute() {
		this.otherAttributeBinding = null;
		unsetBinding("otherAttribute");
		return this;
	}
	
	
	@Override
	public boolean checkBindings(final MethodsWithCommonAttribute2WithAnotherCommonAttributeMatch match) {
		if(bindings.isEmpty())
			return true;
			
		boolean bound = true;
		bound &= fromClazzBinding == null || match.fromClazz().equals(fromClazzBinding);
		bound &= toClazzBinding == null || match.toClazz().equals(toClazzBinding);
		bound &= fromMethodBinding == null || match.fromMethod().equals(fromMethodBinding);
		bound &= toMethodBinding == null || match.toMethod().equals(toMethodBinding);
		bound &= commonAttributeBinding == null || match.commonAttribute().equals(commonAttributeBinding);
		bound &= otherAttributeBinding == null || match.otherAttribute().equals(otherAttributeBinding);
		return bound;
	}
	
	@Override
	public boolean checkConditions(final MethodsWithCommonAttribute2WithAnotherCommonAttributeMatch match) {
		return (!(match.toClazz()).equals(match.fromClazz())) && 
		(!(match.fromMethod()).equals(match.toMethod())) && 
		(!(match.otherAttribute()).equals(match.commonAttribute()));
	}
	
	@Override
	public boolean hasArithmeticExpressions() {
		return false;
	}
	
	@Override
	public boolean hasBooleanExpressions() {
		return false;
	}
	
	@Override
	public boolean hasCountExpressions() {
		return false;
	}
	
	@Override
	public boolean hasParameterExpressions() {
		return false;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributeMatch createMatch(final Map<String, Object> nodes,  Object... args) {
		return new MethodsWithCommonAttribute2WithAnotherCommonAttributeMatch(this, nodes);
	}
	
	@Override
	protected Set<EObject> insertNodesAndMatch(final MethodsWithCommonAttribute2WithAnotherCommonAttributeMatch match) {
		throw new UnsupportedOperationException("The pattern <methodsWithCommonAttribute2WithAnotherCommonAttribute> does not define any attributes to watch.");
	}
}
