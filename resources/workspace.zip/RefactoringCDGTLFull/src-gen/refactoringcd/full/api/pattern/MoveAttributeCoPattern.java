package refactoringcd.full.api.pattern;
		
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import refactoringcd.full.api.match.MoveAttributeCoMatch;
import java.util.Collection;
import java.util.Map;
import org.emoflon.ibex.gt.gtmodel.IBeXGTModel.GTPattern;
import refactoringcd.full.api.match.MoveAttributeMatch;
import refactoringcd.full.api.rule.MoveAttributeRule;
import org.emoflon.ibex.gt.engine.IBeXGTCoPattern;

public class MoveAttributeCoPattern extends IBeXGTCoPattern<MoveAttributeCoPattern, MoveAttributeCoMatch, MoveAttributeRule, MoveAttributeRule, MoveAttributeMatch> {
		
	public MoveAttributeCoPattern(final IBeXGtAPI<?, ?, ?> api, final MoveAttributeRule typedRule, final GTPattern coPattern) {
		super(api, typedRule, coPattern);
	}
	
	@Override
	public Collection<String> getParameterNames() {
		throw new UnsupportedOperationException("Patterns do not have any parameters.");
	}
	
	@Override
	public Map<String, Object> getParameters() {
		throw new UnsupportedOperationException("Patterns do not have any parameters.");
	}
	
	@Override
	public MoveAttributeCoPattern setParameters(final Map<String, Object> parameters) {
		throw new UnsupportedOperationException("Patterns do not have any parameters.");
	}
	
	@Override
	public boolean checkBindings(final MoveAttributeCoMatch match) {
		return true;
	}
		
	@Override
	public boolean checkConditions(final MoveAttributeCoMatch match) {
		return true;
	}

	
	@Override
	public boolean hasArithmeticExpressions() {
		return false;
	}
	
	@Override
	public boolean hasBooleanExpressions() {
		return false;
	}
	
	@Override
	public boolean hasCountExpressions() {
		return false;
	}
	
	@Override
	public boolean hasParameterExpressions() {
		return false;
	}
	
	public MoveAttributeCoMatch createMatch(final Map<String, Object> nodes, Object... args) {
		return new MoveAttributeCoMatch(typedRule, this, (MoveAttributeMatch) args[0], nodes);
	}
}