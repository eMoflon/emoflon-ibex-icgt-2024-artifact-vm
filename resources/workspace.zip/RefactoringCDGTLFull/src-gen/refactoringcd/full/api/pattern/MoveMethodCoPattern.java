package refactoringcd.full.api.pattern;
		
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import refactoringcd.full.api.rule.MoveMethodRule;
import java.util.Collection;
import java.util.Map;
import org.emoflon.ibex.gt.gtmodel.IBeXGTModel.GTPattern;
import refactoringcd.full.api.match.MoveMethodCoMatch;
import org.emoflon.ibex.gt.engine.IBeXGTCoPattern;
import refactoringcd.full.api.match.MoveMethodMatch;

public class MoveMethodCoPattern extends IBeXGTCoPattern<MoveMethodCoPattern, MoveMethodCoMatch, MoveMethodRule, MoveMethodRule, MoveMethodMatch> {
		
	public MoveMethodCoPattern(final IBeXGtAPI<?, ?, ?> api, final MoveMethodRule typedRule, final GTPattern coPattern) {
		super(api, typedRule, coPattern);
	}
	
	@Override
	public Collection<String> getParameterNames() {
		throw new UnsupportedOperationException("Patterns do not have any parameters.");
	}
	
	@Override
	public Map<String, Object> getParameters() {
		throw new UnsupportedOperationException("Patterns do not have any parameters.");
	}
	
	@Override
	public MoveMethodCoPattern setParameters(final Map<String, Object> parameters) {
		throw new UnsupportedOperationException("Patterns do not have any parameters.");
	}
	
	@Override
	public boolean checkBindings(final MoveMethodCoMatch match) {
		return true;
	}
		
	@Override
	public boolean checkConditions(final MoveMethodCoMatch match) {
		return true;
	}

	
	@Override
	public boolean hasArithmeticExpressions() {
		return false;
	}
	
	@Override
	public boolean hasBooleanExpressions() {
		return false;
	}
	
	@Override
	public boolean hasCountExpressions() {
		return false;
	}
	
	@Override
	public boolean hasParameterExpressions() {
		return false;
	}
	
	public MoveMethodCoMatch createMatch(final Map<String, Object> nodes, Object... args) {
		return new MoveMethodCoMatch(typedRule, this, (MoveMethodMatch) args[0], nodes);
	}
}