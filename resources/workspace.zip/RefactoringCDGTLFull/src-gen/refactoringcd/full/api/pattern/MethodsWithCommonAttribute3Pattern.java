package refactoringcd.full.api.pattern;
		
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import java.util.List;
import classDiagram.Attribute;
import java.util.Collection;
import java.util.Map;
import refactoringcd.full.api.match.MethodsWithCommonAttribute3Match;
import java.util.Set;
import org.eclipse.emf.ecore.EObject;
import org.emoflon.ibex.gt.gtmodel.IBeXGTModel.GTPattern;
import classDiagram.Clazz;
import org.emoflon.ibex.gt.engine.IBeXGTPattern;
import classDiagram.Method;

public class MethodsWithCommonAttribute3Pattern extends IBeXGTPattern<MethodsWithCommonAttribute3Pattern, MethodsWithCommonAttribute3Match> {
	
	
	
	protected Clazz fromClazzBinding = null;
	protected Clazz toClazzBinding = null;
	protected Method fromMethodBinding = null;
	protected Method toMethodBinding = null;
	protected Attribute commonAttributeBinding = null;
	
	public MethodsWithCommonAttribute3Pattern(final IBeXGtAPI<?, ?, ?> api, final GTPattern pattern) {
		super(api, pattern);
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of();
	}
	
	@Override
	public Map<String, Object> getParameters() {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	@Override
	public MethodsWithCommonAttribute3Pattern setParameters(final Map<String, Object> parameters) {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	
	public MethodsWithCommonAttribute3Pattern bindFromClazz(final Clazz fromClazz) {
		this.fromClazzBinding = fromClazz;
		setBinding("fromClazz", fromClazz);
		return this;
	}
	
	public MethodsWithCommonAttribute3Pattern unbindFromClazz() {
		this.fromClazzBinding = null;
		unsetBinding("fromClazz");
		return this;
	}
	
	public MethodsWithCommonAttribute3Pattern bindToClazz(final Clazz toClazz) {
		this.toClazzBinding = toClazz;
		setBinding("toClazz", toClazz);
		return this;
	}
	
	public MethodsWithCommonAttribute3Pattern unbindToClazz() {
		this.toClazzBinding = null;
		unsetBinding("toClazz");
		return this;
	}
	
	public MethodsWithCommonAttribute3Pattern bindFromMethod(final Method fromMethod) {
		this.fromMethodBinding = fromMethod;
		setBinding("fromMethod", fromMethod);
		return this;
	}
	
	public MethodsWithCommonAttribute3Pattern unbindFromMethod() {
		this.fromMethodBinding = null;
		unsetBinding("fromMethod");
		return this;
	}
	
	public MethodsWithCommonAttribute3Pattern bindToMethod(final Method toMethod) {
		this.toMethodBinding = toMethod;
		setBinding("toMethod", toMethod);
		return this;
	}
	
	public MethodsWithCommonAttribute3Pattern unbindToMethod() {
		this.toMethodBinding = null;
		unsetBinding("toMethod");
		return this;
	}
	
	public MethodsWithCommonAttribute3Pattern bindCommonAttribute(final Attribute commonAttribute) {
		this.commonAttributeBinding = commonAttribute;
		setBinding("commonAttribute", commonAttribute);
		return this;
	}
	
	public MethodsWithCommonAttribute3Pattern unbindCommonAttribute() {
		this.commonAttributeBinding = null;
		unsetBinding("commonAttribute");
		return this;
	}
	
	
	@Override
	public boolean checkBindings(final MethodsWithCommonAttribute3Match match) {
		if(bindings.isEmpty())
			return true;
			
		boolean bound = true;
		bound &= fromClazzBinding == null || match.fromClazz().equals(fromClazzBinding);
		bound &= toClazzBinding == null || match.toClazz().equals(toClazzBinding);
		bound &= fromMethodBinding == null || match.fromMethod().equals(fromMethodBinding);
		bound &= toMethodBinding == null || match.toMethod().equals(toMethodBinding);
		bound &= commonAttributeBinding == null || match.commonAttribute().equals(commonAttributeBinding);
		return bound;
	}
	
	@Override
	public boolean checkConditions(final MethodsWithCommonAttribute3Match match) {
		return (!(match.toClazz()).equals(match.fromClazz())) && 
		(!(match.toMethod()).equals(match.fromMethod()));
	}
	
	@Override
	public boolean hasArithmeticExpressions() {
		return false;
	}
	
	@Override
	public boolean hasBooleanExpressions() {
		return false;
	}
	
	@Override
	public boolean hasCountExpressions() {
		return false;
	}
	
	@Override
	public boolean hasParameterExpressions() {
		return false;
	}
	
	public MethodsWithCommonAttribute3Match createMatch(final Map<String, Object> nodes,  Object... args) {
		return new MethodsWithCommonAttribute3Match(this, nodes);
	}
	
	@Override
	protected Set<EObject> insertNodesAndMatch(final MethodsWithCommonAttribute3Match match) {
		throw new UnsupportedOperationException("The pattern <methodsWithCommonAttribute3> does not define any attributes to watch.");
	}
}
