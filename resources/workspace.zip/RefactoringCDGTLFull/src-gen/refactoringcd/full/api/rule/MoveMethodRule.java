package refactoringcd.full.api.rule;
		
import classDiagram.ClassDiagramFactory;
import java.util.Collection;
import java.util.Set;
import java.util.HashMap;
import org.eclipse.emf.ecore.EObject;
import org.emoflon.ibex.gt.gtmodel.IBeXGTModel.GTPattern;
import java.util.stream.Collectors;
import refactoringcd.full.api.match.MoveMethodCoMatch;
import org.emoflon.ibex.gt.gtmodel.IBeXGTModel.GTRule;
import refactoringcd.full.api.match.MoveMethodMatch;
import classDiagram.ClassDiagramPackage;
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import java.util.List;
import java.util.Map;
import refactoringcd.full.api.pattern.MoveMethodCoPattern;
import org.emoflon.ibex.gt.engine.IBeXGTRule;
import classDiagram.Clazz;
import java.util.LinkedList;
import classDiagram.Method;

@SuppressWarnings("unused")
public class MoveMethodRule extends IBeXGTRule<MoveMethodRule, MoveMethodRule, MoveMethodMatch, MoveMethodCoPattern, MoveMethodCoMatch> {
	
	protected ClassDiagramFactory classDiagramFactory = ClassDiagramFactory.eINSTANCE;
	
	
	
	protected Clazz fromClazzBinding = null;
	protected Clazz toClazzBinding = null;
	protected Method methodBinding = null;
	
	public MoveMethodRule(final IBeXGtAPI<?, ?, ?> api, final GTRule rule) {
		super(api, rule);
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of();
	}
	
	@Override
	public Map<String, Object> getParameters() {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	@Override
	public MoveMethodRule setParameters(final Map<String, Object> parameters) {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	
	public MoveMethodRule bindFromClazz(final Clazz fromClazz) {
		this.fromClazzBinding = fromClazz;
		setBinding("fromClazz", fromClazz);
		return this;
	}
	
	public MoveMethodRule unbindFromClazz() {
		this.fromClazzBinding = null;
		unsetBinding("fromClazz");
		return this;
	}
	
	public MoveMethodRule bindToClazz(final Clazz toClazz) {
		this.toClazzBinding = toClazz;
		setBinding("toClazz", toClazz);
		return this;
	}
	
	public MoveMethodRule unbindToClazz() {
		this.toClazzBinding = null;
		unsetBinding("toClazz");
		return this;
	}
	
	public MoveMethodRule bindMethod(final Method method) {
		this.methodBinding = method;
		setBinding("method", method);
		return this;
	}
	
	public MoveMethodRule unbindMethod() {
		this.methodBinding = null;
		unsetBinding("method");
		return this;
	}
	
	
	@Override
	public boolean checkBindings(final MoveMethodMatch match) {
		if(bindings.isEmpty())
			return true;
			
		boolean bound = true;
		bound &= fromClazzBinding == null || match.fromClazz().equals(fromClazzBinding);
		bound &= toClazzBinding == null || match.toClazz().equals(toClazzBinding);
		bound &= methodBinding == null || match.method().equals(methodBinding);
		return bound;
	}
		
	@Override
	public boolean checkConditions(final MoveMethodMatch match) {
		return (!(match.fromClazz()).equals(match.toClazz()));
	}

	
	@Override
	public boolean hasArithmeticExpressions() {
		return false;
	}
	
	@Override
	public boolean hasBooleanExpressions() {
		return false;
	}
	
	@Override
	public boolean hasCountExpressions() {
		return false;
	}
	
	@Override
	public boolean hasParameterExpressions() {
		return false;
	}
	
	public MoveMethodMatch createMatch(final Map<String, Object> nodes, Object... args) {
		return new MoveMethodMatch(this, nodes);
	}
	
	@Override
	protected Set<EObject> insertNodesAndMatch(final MoveMethodMatch match) {
		throw new UnsupportedOperationException("The pattern <moveMethod> does not define any attributes to watch.");
	}
	
	protected MoveMethodCoPattern createCoPattern() {
		return new MoveMethodCoPattern(api, this, (GTPattern) rule.getPostcondition());
	}
	
	public boolean hasProbability() {
		return false;
	}
	
	public double getProbability(final MoveMethodMatch match) {
		return 0.0;
	}
	
	protected MoveMethodCoMatch applyInternal(final MoveMethodMatch match) {
		Map<String, Object> coMatchNodes = new HashMap<>();
		coMatchNodes.put("fromClazz", match.fromClazz());
		coMatchNodes.put("method", match.method());
		coMatchNodes.put("toClazz", match.toClazz());
		
		// Delete elements
		gtEngine.deleteEdge(match.fromClazz(), match.method(), rule.getDeletion().getEdges().get(0));
		
		// Create new elements
		
		// Create new edges
		match.toClazz().getFeatures().add(match.method());
		
		ruleApplicationCount++;
		return coPattern.createMatch(coMatchNodes, match);
	}
	
}
