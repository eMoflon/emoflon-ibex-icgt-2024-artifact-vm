package refactoringcd.full.api.rule;
		
import classDiagram.ClassDiagramFactory;
import refactoringcd.full.api.pattern.MoveAttributeCoPattern;
import classDiagram.Attribute;
import java.util.Collection;
import java.util.Set;
import java.util.HashMap;
import org.eclipse.emf.ecore.EObject;
import org.emoflon.ibex.gt.gtmodel.IBeXGTModel.GTPattern;
import refactoringcd.full.api.match.MoveAttributeMatch;
import java.util.stream.Collectors;
import org.emoflon.ibex.gt.gtmodel.IBeXGTModel.GTRule;
import classDiagram.ClassDiagramPackage;
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import refactoringcd.full.api.match.MoveAttributeCoMatch;
import java.util.List;
import java.util.Map;
import org.emoflon.ibex.gt.engine.IBeXGTRule;
import classDiagram.Clazz;
import java.util.LinkedList;

@SuppressWarnings("unused")
public class MoveAttributeRule extends IBeXGTRule<MoveAttributeRule, MoveAttributeRule, MoveAttributeMatch, MoveAttributeCoPattern, MoveAttributeCoMatch> {
	
	protected ClassDiagramFactory classDiagramFactory = ClassDiagramFactory.eINSTANCE;
	
	
	
	protected Clazz fromClazzBinding = null;
	protected Clazz toClazzBinding = null;
	protected Attribute attributeBinding = null;
	
	public MoveAttributeRule(final IBeXGtAPI<?, ?, ?> api, final GTRule rule) {
		super(api, rule);
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of();
	}
	
	@Override
	public Map<String, Object> getParameters() {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	@Override
	public MoveAttributeRule setParameters(final Map<String, Object> parameters) {
		throw new UnsupportedOperationException("This rule does not have any parameters.");
	}
	
	
	public MoveAttributeRule bindFromClazz(final Clazz fromClazz) {
		this.fromClazzBinding = fromClazz;
		setBinding("fromClazz", fromClazz);
		return this;
	}
	
	public MoveAttributeRule unbindFromClazz() {
		this.fromClazzBinding = null;
		unsetBinding("fromClazz");
		return this;
	}
	
	public MoveAttributeRule bindToClazz(final Clazz toClazz) {
		this.toClazzBinding = toClazz;
		setBinding("toClazz", toClazz);
		return this;
	}
	
	public MoveAttributeRule unbindToClazz() {
		this.toClazzBinding = null;
		unsetBinding("toClazz");
		return this;
	}
	
	public MoveAttributeRule bindAttribute(final Attribute attribute) {
		this.attributeBinding = attribute;
		setBinding("attribute", attribute);
		return this;
	}
	
	public MoveAttributeRule unbindAttribute() {
		this.attributeBinding = null;
		unsetBinding("attribute");
		return this;
	}
	
	
	@Override
	public boolean checkBindings(final MoveAttributeMatch match) {
		if(bindings.isEmpty())
			return true;
			
		boolean bound = true;
		bound &= fromClazzBinding == null || match.fromClazz().equals(fromClazzBinding);
		bound &= toClazzBinding == null || match.toClazz().equals(toClazzBinding);
		bound &= attributeBinding == null || match.attribute().equals(attributeBinding);
		return bound;
	}
		
	@Override
	public boolean checkConditions(final MoveAttributeMatch match) {
		return (!(match.toClazz()).equals(match.fromClazz()));
	}

	
	@Override
	public boolean hasArithmeticExpressions() {
		return false;
	}
	
	@Override
	public boolean hasBooleanExpressions() {
		return false;
	}
	
	@Override
	public boolean hasCountExpressions() {
		return false;
	}
	
	@Override
	public boolean hasParameterExpressions() {
		return false;
	}
	
	public MoveAttributeMatch createMatch(final Map<String, Object> nodes, Object... args) {
		return new MoveAttributeMatch(this, nodes);
	}
	
	@Override
	protected Set<EObject> insertNodesAndMatch(final MoveAttributeMatch match) {
		throw new UnsupportedOperationException("The pattern <moveAttribute> does not define any attributes to watch.");
	}
	
	protected MoveAttributeCoPattern createCoPattern() {
		return new MoveAttributeCoPattern(api, this, (GTPattern) rule.getPostcondition());
	}
	
	public boolean hasProbability() {
		return false;
	}
	
	public double getProbability(final MoveAttributeMatch match) {
		return 0.0;
	}
	
	protected MoveAttributeCoMatch applyInternal(final MoveAttributeMatch match) {
		Map<String, Object> coMatchNodes = new HashMap<>();
		coMatchNodes.put("attribute", match.attribute());
		coMatchNodes.put("toClazz", match.toClazz());
		coMatchNodes.put("fromClazz", match.fromClazz());
		
		// Delete elements
		gtEngine.deleteEdge(match.fromClazz(), match.attribute(), rule.getDeletion().getEdges().get(0));
		
		// Create new elements
		
		// Create new edges
		match.toClazz().getFeatures().add(match.attribute());
		
		ruleApplicationCount++;
		return coPattern.createMatch(coMatchNodes, match);
	}
	
}
