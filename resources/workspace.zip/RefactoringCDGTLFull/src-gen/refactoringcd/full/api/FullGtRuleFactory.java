package refactoringcd.full.api;
		
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import org.emoflon.ibex.gt.engine.IBeXGTRuleFactory;
import refactoringcd.full.api.rule.MoveMethodRule;
import refactoringcd.full.api.rule.MoveAttributeRule;
		
public class FullGtRuleFactory extends IBeXGTRuleFactory {	
	
	public FullGtRuleFactory(IBeXGtAPI<?, ?, ?> api) {
			super(api);
	}
	
	protected MoveAttributeRule createMoveAttributeRule() {
		MoveAttributeRule rule = new MoveAttributeRule(api, api.getGTEngine().getRule("moveAttribute"));
		return rule;
	}
	
	protected MoveMethodRule createMoveMethodRule() {
		MoveMethodRule rule = new MoveMethodRule(api, api.getGTEngine().getRule("moveMethod"));
		return rule;
	}
	
}