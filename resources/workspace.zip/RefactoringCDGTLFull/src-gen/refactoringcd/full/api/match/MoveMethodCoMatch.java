package refactoringcd.full.api.match;
		
import org.emoflon.ibex.gt.engine.IBeXGTCoMatch;
import java.util.List;
import refactoringcd.full.api.rule.MoveMethodRule;
import java.util.Collection;
import java.util.Map;
import refactoringcd.full.api.pattern.MoveMethodCoPattern;
import classDiagram.Clazz;
import classDiagram.Method;

public class MoveMethodCoMatch extends IBeXGTCoMatch<MoveMethodCoMatch, MoveMethodCoPattern, MoveMethodRule, MoveMethodRule, MoveMethodMatch> {
	
	protected Clazz fromClazz;
	protected Clazz toClazz;
	protected Method method;
	
	public MoveMethodCoMatch(final MoveMethodRule typedRule, final MoveMethodCoPattern typedCoPattern, final MoveMethodMatch typedMatch, final Map<String, Object> nodes) {
		super(typedRule, typedCoPattern, typedMatch, nodes);
	}
	
	public MoveMethodCoMatch(final MoveMethodCoMatch other) {
		super(other);
	}
	
	@Override
	public String getPatternName() {
		return "moveMethod";
	}
	
	@Override
	public Object get(String name) {
		return switch(name) {
			case "fromClazz" -> {yield fromClazz;}
			case "toClazz" -> {yield toClazz;}
			case "method" -> {yield method;}
			default -> throw new NullPointerException("Unknown parameter name: " + name);
		};
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of("fromClazz", 
		"toClazz", 
		"method");
	}
	
	@Override
	public Collection<Object> getObjects() {
		return List.of(fromClazz, 
		toClazz, 
		method);
	}

	@Override
	protected void initialize(final Map<String, Object> nodes) {
		fromClazz = (Clazz) nodes.get("fromClazz");
		toClazz = (Clazz) nodes.get("toClazz");
		method = (Method) nodes.get("method");
	}
	
	@Override
	protected void initialize(final MoveMethodCoMatch other) {
		fromClazz = other.fromClazz;
		toClazz = other.toClazz;
		method = other.method;
	}
	
	@Override
	public boolean checkConditions() {
		return typedPattern.checkConditions(this);
	}
	
	@Override
	public boolean checkBindings() {
		return typedPattern.checkBindings(this);
	}
	
	@Override
	public MoveMethodCoMatch copy() {
		return new MoveMethodCoMatch(this);
	}
	
	public Clazz fromClazz() {
		return fromClazz;
	}
	
	public Clazz toClazz() {
		return toClazz;
	}
	
	public Method method() {
		return method;
	}
	
}