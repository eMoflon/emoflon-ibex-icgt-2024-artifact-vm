package refactoringcd.full.api.match;
		
import java.util.List;
import classDiagram.Attribute;
import org.emoflon.ibex.gt.engine.IBeXGTMatch;
import java.util.Collection;
import java.util.Map;
import refactoringcd.full.api.pattern.MovingMethodWithAttributeDependencyTogetherPattern;
import classDiagram.Clazz;
import classDiagram.Method;

public class MovingMethodWithAttributeDependencyTogetherMatch extends IBeXGTMatch<MovingMethodWithAttributeDependencyTogetherMatch, MovingMethodWithAttributeDependencyTogetherPattern> {
	
	protected Clazz fromClazz;
	protected Clazz toClazz;
	protected Method method;
	protected Attribute attribute;
	
	public MovingMethodWithAttributeDependencyTogetherMatch(final MovingMethodWithAttributeDependencyTogetherPattern typedPattern, final Map<String, Object> nodes) {
		super(typedPattern, nodes);
	}
	
	public MovingMethodWithAttributeDependencyTogetherMatch(final MovingMethodWithAttributeDependencyTogetherMatch other) {
		super(other);
	}
	
	@Override
	public String getPatternName() {
		return "movingMethodWithAttributeDependencyTogether";
	}
	
	@Override
	public Object get(String name) {
		return switch(name) {
			case "fromClazz" -> {yield fromClazz;}
			case "toClazz" -> {yield toClazz;}
			case "method" -> {yield method;}
			case "attribute" -> {yield attribute;}
			default -> throw new NullPointerException("Unknown parameter name: " + name);
		};
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of("fromClazz", 
		"toClazz", 
		"method", 
		"attribute");
	}
	
	@Override
	public Collection<Object> getObjects() {
		return List.of(fromClazz, 
		toClazz, 
		method, 
		attribute);
	}

	@Override
	protected void initialize(final Map<String, Object> nodes) {
		fromClazz = (Clazz) nodes.get("fromClazz");
		toClazz = (Clazz) nodes.get("toClazz");
		method = (Method) nodes.get("method");
		attribute = (Attribute) nodes.get("attribute");
	}
	
	@Override
	protected void initialize(final MovingMethodWithAttributeDependencyTogetherMatch other) {
		fromClazz = other.fromClazz;
		toClazz = other.toClazz;
		method = other.method;
		attribute = other.attribute;
	}
	
	@Override
	public boolean checkConditions() {
		return typedPattern.checkConditions(this);
	}
	
	@Override
	public boolean checkBindings() {
		return typedPattern.checkBindings(this);
	}
	
	@Override
	public MovingMethodWithAttributeDependencyTogetherMatch copy() {
		return new MovingMethodWithAttributeDependencyTogetherMatch(this);
	}
	
	public Clazz fromClazz() {
		return fromClazz;
	}
	
	public Clazz toClazz() {
		return toClazz;
	}
	
	public Method method() {
		return method;
	}
	
	public Attribute attribute() {
		return attribute;
	}
	
}