package refactoringcd.full.api.match;
		
import java.util.List;
import org.emoflon.ibex.gt.engine.IBeXGTMatch;
import java.util.Collection;
import java.util.Map;
import refactoringcd.full.api.pattern.MovingMethodToOtherMethodWithCommonDependencyPattern;
import classDiagram.Clazz;
import classDiagram.Method;

public class MovingMethodToOtherMethodWithCommonDependencyMatch extends IBeXGTMatch<MovingMethodToOtherMethodWithCommonDependencyMatch, MovingMethodToOtherMethodWithCommonDependencyPattern> {
	
	protected Clazz fromClazz;
	protected Clazz toClazz;
	protected Method fromMethod;
	protected Method toMethod;
	
	public MovingMethodToOtherMethodWithCommonDependencyMatch(final MovingMethodToOtherMethodWithCommonDependencyPattern typedPattern, final Map<String, Object> nodes) {
		super(typedPattern, nodes);
	}
	
	public MovingMethodToOtherMethodWithCommonDependencyMatch(final MovingMethodToOtherMethodWithCommonDependencyMatch other) {
		super(other);
	}
	
	@Override
	public String getPatternName() {
		return "movingMethodToOtherMethodWithCommonDependency";
	}
	
	@Override
	public Object get(String name) {
		return switch(name) {
			case "fromClazz" -> {yield fromClazz;}
			case "toClazz" -> {yield toClazz;}
			case "fromMethod" -> {yield fromMethod;}
			case "toMethod" -> {yield toMethod;}
			default -> throw new NullPointerException("Unknown parameter name: " + name);
		};
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of("fromClazz", 
		"toClazz", 
		"fromMethod", 
		"toMethod");
	}
	
	@Override
	public Collection<Object> getObjects() {
		return List.of(fromClazz, 
		toClazz, 
		fromMethod, 
		toMethod);
	}

	@Override
	protected void initialize(final Map<String, Object> nodes) {
		fromClazz = (Clazz) nodes.get("fromClazz");
		toClazz = (Clazz) nodes.get("toClazz");
		fromMethod = (Method) nodes.get("fromMethod");
		toMethod = (Method) nodes.get("toMethod");
	}
	
	@Override
	protected void initialize(final MovingMethodToOtherMethodWithCommonDependencyMatch other) {
		fromClazz = other.fromClazz;
		toClazz = other.toClazz;
		fromMethod = other.fromMethod;
		toMethod = other.toMethod;
	}
	
	@Override
	public boolean checkConditions() {
		return typedPattern.checkConditions(this);
	}
	
	@Override
	public boolean checkBindings() {
		return typedPattern.checkBindings(this);
	}
	
	@Override
	public MovingMethodToOtherMethodWithCommonDependencyMatch copy() {
		return new MovingMethodToOtherMethodWithCommonDependencyMatch(this);
	}
	
	public Clazz fromClazz() {
		return fromClazz;
	}
	
	public Clazz toClazz() {
		return toClazz;
	}
	
	public Method fromMethod() {
		return fromMethod;
	}
	
	public Method toMethod() {
		return toMethod;
	}
	
}