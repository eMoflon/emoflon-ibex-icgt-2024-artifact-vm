package refactoringcd.full.api.match;
		
import java.util.List;
import classDiagram.Attribute;
import org.emoflon.ibex.gt.engine.IBeXGTMatch;
import java.util.Collection;
import java.util.Map;
import classDiagram.Clazz;
import refactoringcd.full.api.pattern.MethodsWithOtherCommonAttribute4Pattern;
import classDiagram.Method;

public class MethodsWithOtherCommonAttribute4Match extends IBeXGTMatch<MethodsWithOtherCommonAttribute4Match, MethodsWithOtherCommonAttribute4Pattern> {
	
	protected Clazz fromClazz;
	protected Clazz toClazz;
	protected Method fromMethod;
	protected Method toMethod;
	protected Attribute commonAttribute;
	protected Attribute otherAttribute;
	
	public MethodsWithOtherCommonAttribute4Match(final MethodsWithOtherCommonAttribute4Pattern typedPattern, final Map<String, Object> nodes) {
		super(typedPattern, nodes);
	}
	
	public MethodsWithOtherCommonAttribute4Match(final MethodsWithOtherCommonAttribute4Match other) {
		super(other);
	}
	
	@Override
	public String getPatternName() {
		return "methodsWithOtherCommonAttribute4";
	}
	
	@Override
	public Object get(String name) {
		return switch(name) {
			case "fromClazz" -> {yield fromClazz;}
			case "toClazz" -> {yield toClazz;}
			case "fromMethod" -> {yield fromMethod;}
			case "toMethod" -> {yield toMethod;}
			case "commonAttribute" -> {yield commonAttribute;}
			case "otherAttribute" -> {yield otherAttribute;}
			default -> throw new NullPointerException("Unknown parameter name: " + name);
		};
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of("fromClazz", 
		"toClazz", 
		"fromMethod", 
		"toMethod", 
		"commonAttribute", 
		"otherAttribute");
	}
	
	@Override
	public Collection<Object> getObjects() {
		return List.of(fromClazz, 
		toClazz, 
		fromMethod, 
		toMethod, 
		commonAttribute, 
		otherAttribute);
	}

	@Override
	protected void initialize(final Map<String, Object> nodes) {
		fromClazz = (Clazz) nodes.get("fromClazz");
		toClazz = (Clazz) nodes.get("toClazz");
		fromMethod = (Method) nodes.get("fromMethod");
		toMethod = (Method) nodes.get("toMethod");
		commonAttribute = (Attribute) nodes.get("commonAttribute");
		otherAttribute = (Attribute) nodes.get("otherAttribute");
	}
	
	@Override
	protected void initialize(final MethodsWithOtherCommonAttribute4Match other) {
		fromClazz = other.fromClazz;
		toClazz = other.toClazz;
		fromMethod = other.fromMethod;
		toMethod = other.toMethod;
		commonAttribute = other.commonAttribute;
		otherAttribute = other.otherAttribute;
	}
	
	@Override
	public boolean checkConditions() {
		return typedPattern.checkConditions(this);
	}
	
	@Override
	public boolean checkBindings() {
		return typedPattern.checkBindings(this);
	}
	
	@Override
	public MethodsWithOtherCommonAttribute4Match copy() {
		return new MethodsWithOtherCommonAttribute4Match(this);
	}
	
	public Clazz fromClazz() {
		return fromClazz;
	}
	
	public Clazz toClazz() {
		return toClazz;
	}
	
	public Method fromMethod() {
		return fromMethod;
	}
	
	public Method toMethod() {
		return toMethod;
	}
	
	public Attribute commonAttribute() {
		return commonAttribute;
	}
	
	public Attribute otherAttribute() {
		return otherAttribute;
	}
	
}