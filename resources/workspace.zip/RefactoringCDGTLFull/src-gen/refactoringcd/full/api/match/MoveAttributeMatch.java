package refactoringcd.full.api.match;
		
import java.util.List;
import classDiagram.Attribute;
import org.emoflon.ibex.gt.engine.IBeXGTMatch;
import java.util.Collection;
import java.util.Map;
import classDiagram.Clazz;
import refactoringcd.full.api.rule.MoveAttributeRule;

public class MoveAttributeMatch extends IBeXGTMatch<MoveAttributeMatch, MoveAttributeRule> {
	
	protected Clazz fromClazz;
	protected Clazz toClazz;
	protected Attribute attribute;
	
	public MoveAttributeMatch(final MoveAttributeRule typedPattern, final Map<String, Object> nodes) {
		super(typedPattern, nodes);
	}
	
	public MoveAttributeMatch(final MoveAttributeMatch other) {
		super(other);
	}
	
	@Override
	public String getPatternName() {
		return "moveAttribute";
	}
	
	@Override
	public Object get(String name) {
		return switch(name) {
			case "fromClazz" -> {yield fromClazz;}
			case "toClazz" -> {yield toClazz;}
			case "attribute" -> {yield attribute;}
			default -> throw new NullPointerException("Unknown parameter name: " + name);
		};
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of("fromClazz", 
		"toClazz", 
		"attribute");
	}
	
	@Override
	public Collection<Object> getObjects() {
		return List.of(fromClazz, 
		toClazz, 
		attribute);
	}

	@Override
	protected void initialize(final Map<String, Object> nodes) {
		fromClazz = (Clazz) nodes.get("fromClazz");
		toClazz = (Clazz) nodes.get("toClazz");
		attribute = (Attribute) nodes.get("attribute");
	}
	
	@Override
	protected void initialize(final MoveAttributeMatch other) {
		fromClazz = other.fromClazz;
		toClazz = other.toClazz;
		attribute = other.attribute;
	}
	
	@Override
	public boolean checkConditions() {
		return typedPattern.checkConditions(this);
	}
	
	@Override
	public boolean checkBindings() {
		return typedPattern.checkBindings(this);
	}
	
	@Override
	public MoveAttributeMatch copy() {
		return new MoveAttributeMatch(this);
	}
	
	public Clazz fromClazz() {
		return fromClazz;
	}
	
	public Clazz toClazz() {
		return toClazz;
	}
	
	public Attribute attribute() {
		return attribute;
	}
	
}