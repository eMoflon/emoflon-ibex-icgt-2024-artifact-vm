package refactoringcd.full.api.match;
		
import java.util.List;
import classDiagram.Attribute;
import org.emoflon.ibex.gt.engine.IBeXGTMatch;
import java.util.Collection;
import java.util.Map;
import classDiagram.Clazz;
import refactoringcd.full.api.pattern.MethodsWithCommonAttribute2Pattern;
import classDiagram.Method;

public class MethodsWithCommonAttribute2Match extends IBeXGTMatch<MethodsWithCommonAttribute2Match, MethodsWithCommonAttribute2Pattern> {
	
	protected Clazz fromClazz;
	protected Clazz toClazz;
	protected Method fromMethod;
	protected Method toMethod;
	protected Attribute commonAttribute;
	
	public MethodsWithCommonAttribute2Match(final MethodsWithCommonAttribute2Pattern typedPattern, final Map<String, Object> nodes) {
		super(typedPattern, nodes);
	}
	
	public MethodsWithCommonAttribute2Match(final MethodsWithCommonAttribute2Match other) {
		super(other);
	}
	
	@Override
	public String getPatternName() {
		return "methodsWithCommonAttribute2";
	}
	
	@Override
	public Object get(String name) {
		return switch(name) {
			case "fromClazz" -> {yield fromClazz;}
			case "toClazz" -> {yield toClazz;}
			case "fromMethod" -> {yield fromMethod;}
			case "toMethod" -> {yield toMethod;}
			case "commonAttribute" -> {yield commonAttribute;}
			default -> throw new NullPointerException("Unknown parameter name: " + name);
		};
	}
	
	@Override
	public Collection<String> getParameterNames() {
		return List.of("fromClazz", 
		"toClazz", 
		"fromMethod", 
		"toMethod", 
		"commonAttribute");
	}
	
	@Override
	public Collection<Object> getObjects() {
		return List.of(fromClazz, 
		toClazz, 
		fromMethod, 
		toMethod, 
		commonAttribute);
	}

	@Override
	protected void initialize(final Map<String, Object> nodes) {
		fromClazz = (Clazz) nodes.get("fromClazz");
		toClazz = (Clazz) nodes.get("toClazz");
		fromMethod = (Method) nodes.get("fromMethod");
		toMethod = (Method) nodes.get("toMethod");
		commonAttribute = (Attribute) nodes.get("commonAttribute");
	}
	
	@Override
	protected void initialize(final MethodsWithCommonAttribute2Match other) {
		fromClazz = other.fromClazz;
		toClazz = other.toClazz;
		fromMethod = other.fromMethod;
		toMethod = other.toMethod;
		commonAttribute = other.commonAttribute;
	}
	
	@Override
	public boolean checkConditions() {
		return typedPattern.checkConditions(this);
	}
	
	@Override
	public boolean checkBindings() {
		return typedPattern.checkBindings(this);
	}
	
	@Override
	public MethodsWithCommonAttribute2Match copy() {
		return new MethodsWithCommonAttribute2Match(this);
	}
	
	public Clazz fromClazz() {
		return fromClazz;
	}
	
	public Clazz toClazz() {
		return toClazz;
	}
	
	public Method fromMethod() {
		return fromMethod;
	}
	
	public Method toMethod() {
		return toMethod;
	}
	
	public Attribute commonAttribute() {
		return commonAttribute;
	}
	
}