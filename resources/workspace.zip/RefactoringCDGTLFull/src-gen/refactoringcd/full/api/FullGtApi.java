package refactoringcd.full.api;
		
import refactoringcd.full.api.pattern.MethodsWithCommonAttributePattern;
import refactoringcd.full.api.pattern.MoveLastCommonAttributeToOtherClassPattern;
import refactoringcd.full.api.pattern.IntactMethodAttributeDependencyPattern;
import org.eclipse.emf.ecore.EcorePackage;
import refactoringcd.full.api.rule.MoveAttributeRule;
import org.eclipse.emf.ecore.resource.ResourceSet;
import classDiagram.ClassDiagramPackage;
import org.emoflon.ibex.gt.api.IBeXGtAPI;
import refactoringcd.full.api.pattern.MethodsWithCommonAttribute4Pattern;
import refactoringcd.full.api.pattern.MethodsWithCommonAttribute3Pattern;
import refactoringcd.full.api.rule.MoveMethodRule;
import refactoringcd.full.api.pattern.MovingMethodToOtherMethodWithoutCommonDependencyPattern;
import refactoringcd.full.api.pattern.MoveFirstCommonAttributeToOtherClassPattern;
import org.emoflon.ibex.gt.engine.IBeXGTPatternMatcher;
import refactoringcd.full.api.pattern.MovingMethodToOtherMethodWithCommonDependencyPattern;
import refactoringcd.full.api.pattern.MethodsWithCommonAttribute2WithAnotherCommonAttributePattern;
import refactoringcd.full.api.pattern.MovingMethodWithAttributeDependencyTogetherPattern;
import refactoringcd.full.api.pattern.MethodsWithCommonAttribute2Pattern;
import refactoringcd.full.api.pattern.MethodsWithOtherCommonAttribute4Pattern;

public abstract class FullGtApi <ENGINE extends IBeXGTPatternMatcher<?>> extends IBeXGtAPI<ENGINE, FullGtPatternFactory, FullGtRuleFactory> {
	
	protected IntactMethodAttributeDependencyPattern intactMethodAttributeDependency;
	protected MethodsWithCommonAttributePattern methodsWithCommonAttribute;
	protected MethodsWithCommonAttribute2Pattern methodsWithCommonAttribute2;
	protected MethodsWithCommonAttribute2WithAnotherCommonAttributePattern methodsWithCommonAttribute2WithAnotherCommonAttribute;
	protected MethodsWithCommonAttribute3Pattern methodsWithCommonAttribute3;
	protected MethodsWithCommonAttribute4Pattern methodsWithCommonAttribute4;
	protected MethodsWithOtherCommonAttribute4Pattern methodsWithOtherCommonAttribute4;
	protected MoveFirstCommonAttributeToOtherClassPattern moveFirstCommonAttributeToOtherClass;
	protected MoveLastCommonAttributeToOtherClassPattern moveLastCommonAttributeToOtherClass;
	protected MovingMethodToOtherMethodWithCommonDependencyPattern movingMethodToOtherMethodWithCommonDependency;
	protected MovingMethodToOtherMethodWithoutCommonDependencyPattern movingMethodToOtherMethodWithoutCommonDependency;
	protected MovingMethodWithAttributeDependencyTogetherPattern movingMethodWithAttributeDependencyTogether;
	
	protected MoveAttributeRule moveAttribute;
	protected MoveMethodRule moveMethod;
	
	@Override
	public String getWorkspacePath() {
		return "C:/ES/Dev/workspaces/ibex-workspaces/runtime-TGG3-stateless/git/TGG-3.0-Prototype/RefactoringCDGTLFull/../";
	}
	
	@Override
	public String getProjectPath() {
		return "C:/ES/Dev/workspaces/ibex-workspaces/runtime-TGG3-stateless/git/TGG-3.0-Prototype/RefactoringCDGTLFull";
	}
	
	@Override
	public String getIBeXModelPath() {
		return "C:/ES/Dev/workspaces/ibex-workspaces/runtime-TGG3-stateless/git/TGG-3.0-Prototype/RefactoringCDGTLFull/src-gen/refactoringcd/full/api/ibex_gt_model.xmi";
	}
	
	@Override
	public String getProjectName() {
		return "RefactoringCDGTLFull";
	}
	
	@Override
	protected FullGtPatternFactory createPatternFactory() {
		return new 	FullGtPatternFactory(this);
	}
	
	@Override
	protected FullGtRuleFactory createRuleFactory() {
		return new 	FullGtRuleFactory(this);
	}
	
	@Override
	protected void initializeRules() {
		moveAttribute = ruleFactory.createMoveAttributeRule();
		moveMethod = ruleFactory.createMoveMethodRule();
	}
	
	@Override
	protected void initializePatterns() {
		intactMethodAttributeDependency = patternFactory.createIntactMethodAttributeDependencyPattern();
		methodsWithCommonAttribute = patternFactory.createMethodsWithCommonAttributePattern();
		methodsWithCommonAttribute2 = patternFactory.createMethodsWithCommonAttribute2Pattern();
		methodsWithCommonAttribute2WithAnotherCommonAttribute = patternFactory.createMethodsWithCommonAttribute2WithAnotherCommonAttributePattern();
		methodsWithCommonAttribute3 = patternFactory.createMethodsWithCommonAttribute3Pattern();
		methodsWithCommonAttribute4 = patternFactory.createMethodsWithCommonAttribute4Pattern();
		methodsWithOtherCommonAttribute4 = patternFactory.createMethodsWithOtherCommonAttribute4Pattern();
		moveFirstCommonAttributeToOtherClass = patternFactory.createMoveFirstCommonAttributeToOtherClassPattern();
		moveLastCommonAttributeToOtherClass = patternFactory.createMoveLastCommonAttributeToOtherClassPattern();
		movingMethodToOtherMethodWithCommonDependency = patternFactory.createMovingMethodToOtherMethodWithCommonDependencyPattern();
		movingMethodToOtherMethodWithoutCommonDependency = patternFactory.createMovingMethodToOtherMethodWithoutCommonDependencyPattern();
		movingMethodWithAttributeDependencyTogether = patternFactory.createMovingMethodWithAttributeDependencyTogetherPattern();
	}
	
	@Override
	protected void registerMetamodels(final ResourceSet rs) {
		rs.getPackageRegistry().put(ClassDiagramPackage.eINSTANCE.getNsURI(), ClassDiagramPackage.eINSTANCE);
		rs.getPackageRegistry().put(EcorePackage.eINSTANCE.getNsURI(), EcorePackage.eINSTANCE);
	}
	
	public IntactMethodAttributeDependencyPattern intactMethodAttributeDependency() {
		return 	intactMethodAttributeDependency;
	}
	
	public MethodsWithCommonAttributePattern methodsWithCommonAttribute() {
		return 	methodsWithCommonAttribute;
	}
	
	public MethodsWithCommonAttribute2Pattern methodsWithCommonAttribute2() {
		return 	methodsWithCommonAttribute2;
	}
	
	public MethodsWithCommonAttribute2WithAnotherCommonAttributePattern methodsWithCommonAttribute2WithAnotherCommonAttribute() {
		return 	methodsWithCommonAttribute2WithAnotherCommonAttribute;
	}
	
	public MethodsWithCommonAttribute3Pattern methodsWithCommonAttribute3() {
		return 	methodsWithCommonAttribute3;
	}
	
	public MethodsWithCommonAttribute4Pattern methodsWithCommonAttribute4() {
		return 	methodsWithCommonAttribute4;
	}
	
	public MethodsWithOtherCommonAttribute4Pattern methodsWithOtherCommonAttribute4() {
		return 	methodsWithOtherCommonAttribute4;
	}
	
	public MoveFirstCommonAttributeToOtherClassPattern moveFirstCommonAttributeToOtherClass() {
		return 	moveFirstCommonAttributeToOtherClass;
	}
	
	public MoveLastCommonAttributeToOtherClassPattern moveLastCommonAttributeToOtherClass() {
		return 	moveLastCommonAttributeToOtherClass;
	}
	
	public MovingMethodToOtherMethodWithCommonDependencyPattern movingMethodToOtherMethodWithCommonDependency() {
		return 	movingMethodToOtherMethodWithCommonDependency;
	}
	
	public MovingMethodToOtherMethodWithoutCommonDependencyPattern movingMethodToOtherMethodWithoutCommonDependency() {
		return 	movingMethodToOtherMethodWithoutCommonDependency;
	}
	
	public MovingMethodWithAttributeDependencyTogetherPattern movingMethodWithAttributeDependencyTogether() {
		return 	movingMethodWithAttributeDependencyTogether;
	}
	
	public MoveAttributeRule moveAttribute() {
		return 	moveAttribute;
	}
	public MoveMethodRule moveMethod() {
		return 	moveMethod;
	}
	
}
