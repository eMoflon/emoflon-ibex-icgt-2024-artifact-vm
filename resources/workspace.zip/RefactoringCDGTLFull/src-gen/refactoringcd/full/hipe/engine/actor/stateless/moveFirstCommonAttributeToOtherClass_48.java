package refactoringcd.full.hipe.engine.actor.stateless;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;

import hipe.engine.actor.Port;
import hipe.engine.util.HiPESet;
import hipe.engine.match.EdgeMatch;
import hipe.engine.match.HMatch;
import hipe.engine.match.OverlapMatch;
import hipe.engine.match.LocalSearchMatch;
import hipe.engine.actor.junction.PortJunction;
import hipe.engine.actor.junction.PortJunctionLeft;
import hipe.engine.actor.junction.PortJunctionRight;
import hipe.engine.message.input.AttributeChanged;
import hipe.engine.message.input.ReferenceAdded;
import hipe.engine.message.input.ReferenceDeleted;
import hipe.engine.message.production.MatchAdded;
import hipe.engine.message.production.MatchDeleted;
import hipe.engine.message.stateless.*;
import hipe.engine.util.CollectionUtil;

import hipe.network.LocalSearchNode;

import hipe.generic.match.GenericJunctionMatch;
import hipe.generic.actor.junction.GenericJunctionActor;
import hipe.generic.actor.local.GenericLocalSearchActor;
import hipe.generic.actor.stateless.*;
import hipe.generic.actor.stateless.enums.*;
import hipe.generic.actor.stateless.search.*;
import hipe.generic.actor.search.misc.*;

import org.eclipse.emf.ecore.EObject;

public class moveFirstCommonAttributeToOtherClass_48 extends GenericStatelessSearchActor{
	ConstraintChecker node_constraint;
	ConstraintChecker node_constraint_0;
	DeltaAwareEdgeExplorer edge_explorer;
	PACQueryExplorer pac;
	NACQueryChecker nac;
	
	SearchOrchestration edge_explorer_0_orchestration;
	SearchOrchestration edge_explorer_1_orchestration;
	SearchOrchestration edge_explorer_2_orchestration;
	SearchOrchestration pac_orchestration;
	SearchOrchestration nac_orchestration;
	SearchOrchestration disjoint_explorer_0_orchestration;
	SearchOrchestration disjoint_explorer_1_orchestration;
	SearchOrchestration disjoint_explorer_2_orchestration;
	
	@Override
	protected void initializeSearchComponents() {
		node_constraint = new ConstraintChecker(this, this::node_constraint_method);
		name2explorer.put("node_constraint", node_constraint);
		node_constraint_0 = new ConstraintChecker(this, this::node_constraint_0_method);
		name2explorer.put("node_constraint_0", node_constraint_0);
		EdgeLookupMethods edge_explorer_methods = new EdgeLookupMethods();
						edge_explorer_methods.checkSourceType = (o) -> o instanceof classDiagram.Clazz;
						edge_explorer_methods.checkTargetType = (o) -> o instanceof classDiagram.Attribute;
						edge_explorer_methods.multi_lookup = (o) -> ((classDiagram.Clazz) o).getFeatures().stream().filter(obj -> obj instanceof classDiagram.Attribute).collect(Collectors.toList());
						edge_explorer_methods.unique_opposite_lookup = (o) -> {EObject result = ((EObject) o).eContainer(); if(result instanceof classDiagram.Clazz) return edge_explorer_methods.multi_lookup.apply(result).contains(o) ? result : null; else return null;};
						edge_explorer = new DeltaAwareEdgeExplorer(this, 0, 4, edge_explorer_methods, classDiagram.ClassDiagramPackage.eINSTANCE.getClazz_Features());
		name2explorer.put("edge_explorer", edge_explorer);
		pac = new PACQueryExplorer(this, 0, "methodsWithCommonAttribute2_12", name2actor.get("methodsWithCommonAttribute2_12"), 0, 4, 1, 2, 3);
		name2explorer.put("pac", pac);
		nac = new NACQueryChecker(this, 1, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18"), 0, 4, 1, 2, 3);
		name2explorer.put("nac", nac);
	}
	
	@Override
	protected void initializeOrchestration() {
		edge_explorer_0_orchestration = initializeOrchestration(node.getOrchestrations().get(0).getPlan());
		edge_explorer_1_orchestration = initializeOrchestration(node.getOrchestrations().get(1).getPlan());
		edge_explorer_2_orchestration = initializeOrchestration(node.getOrchestrations().get(2).getPlan());
		pac_orchestration = initializeOrchestration(node.getOrchestrations().get(3).getPlan());
		nac_orchestration = initializeOrchestration(node.getOrchestrations().get(4).getPlan());
		disjoint_explorer_0_orchestration = initializeOrchestration(node.getOrchestrations().get(5).getPlan());
		disjoint_explorer_1_orchestration = initializeOrchestration(node.getOrchestrations().get(6).getPlan());
		disjoint_explorer_2_orchestration = initializeOrchestration(node.getOrchestrations().get(7).getPlan());
		
		localNodeOrchestrations = new SearchOrchestration[1];
		localNodeOrchestrations[0] = initializeOrchestration(node.getLocalNodeOrchestration().get(0).getPlan());
	}
	
	@Override
	protected void added(MatchAdded<HMatch> msg) {
		initialMessage = msg.initialMessage;

		HMatch match = msg.input;
		Object[] objs = match.getNodes();
		outer: switch(match.creator) {
			case "methodsWithCommonAttribute2_12": 
				{
					var inputMatch = (StatelessDeltaMatch) match;
					if(objs[1] instanceof classDiagram.Clazz)
					if(objs[4] instanceof classDiagram.Attribute)
					if(objs[0] instanceof classDiagram.Clazz)
					if(objs[2] instanceof classDiagram.Method)
					if(objs[3] instanceof classDiagram.Method)
					{
						var match_0 = new StatelessDeltaMatch(msg, "moveFirstCommonAttributeToOtherClass_48", 5, 2, inputMatch.deltaMode);
						match_0.registerInvocationMessage(msg, 0);
						match_0.getNodes()[0] = objs[1];
						match_0.getNodes()[4] = objs[4];
						match_0.getNodes()[1] = objs[0];
						match_0.getNodes()[2] = objs[2];
						match_0.getNodes()[3] = objs[3];
						
						for(var inputSignatureIndex : inputMatch.deltaSignatureBindingIndices) {
							switch(inputSignatureIndex) {
							case 1: match_0.registerSignatureIndex(0); break;
							case 4: match_0.registerSignatureIndex(4); break;
							case 0: match_0.registerSignatureIndex(1); break;
							case 2: match_0.registerSignatureIndex(2); break;
							case 3: match_0.registerSignatureIndex(3); break;
							}
						}
						
						// start search
						start(pac_orchestration, StatelessInputType.PAC, match_0);
					}
				}
				break;
			case "methodsWithCommonAttribute2WithAnotherCommonAttribute_18": 
				{
					var inputMatch = (StatelessDeltaMatch) match;
					if(objs[0] instanceof classDiagram.Clazz)
					if(objs[5] instanceof classDiagram.Attribute)
					if(objs[1] instanceof classDiagram.Clazz)
					if(objs[2] instanceof classDiagram.Method)
					if(objs[3] instanceof classDiagram.Method)
					{
						var match_1 = new StatelessDeltaMatch(msg, "moveFirstCommonAttributeToOtherClass_48", 5, 2, UsingDeltaMode.DELETE);
						match_1.registerInvocationMessage(msg, 1);
						match_1.getNodes()[0] = objs[0];
						match_1.getNodes()[4] = objs[5];
						match_1.getNodes()[1] = objs[1];
						match_1.getNodes()[2] = objs[2];
						match_1.getNodes()[3] = objs[3];
						
						for(var inputSignatureIndex : inputMatch.deltaSignatureBindingIndices) {
							switch(inputSignatureIndex) {
								case 0: break outer;
								case 5: break outer;
								case 1: break outer;
								case 2: break outer;
								case 3: break outer;
							}
						}
						
						// start search
						start(nac_orchestration, StatelessInputType.NAC, match_1);
					}
				}
				break;
			default: throw new RuntimeException("Detected unknown match from " + msg.input.creator);
		}
		
		msg.initialMessage.decrement();
	}

	@Override
	protected void removed(MatchDeleted<HMatch> msg) {
		initialMessage = msg.initialMessage;

		HMatch match = msg.input;
		Object[] objs = match.getNodes();

		outer: switch(match.creator) {
			case "methodsWithCommonAttribute2_12": 
				{
					var inputMatch = (StatelessDeltaMatch) match;
					if(objs[1] instanceof classDiagram.Clazz)
					if(objs[4] instanceof classDiagram.Attribute)
					if(objs[0] instanceof classDiagram.Clazz)
					if(objs[2] instanceof classDiagram.Method)
					if(objs[3] instanceof classDiagram.Method)
					{
						var match_0 = new StatelessDeltaMatch(msg, "moveFirstCommonAttributeToOtherClass_48", 5, 2, inputMatch.deltaMode);
						match_0.registerInvocationMessage(msg, 0);
						match_0.getNodes()[0] = objs[1];
						match_0.getNodes()[4] = objs[4];
						match_0.getNodes()[1] = objs[0];
						match_0.getNodes()[2] = objs[2];
						match_0.getNodes()[3] = objs[3];
						
						for(var inputSignatureIndex : inputMatch.deltaSignatureBindingIndices) {
							switch(inputSignatureIndex) {
							case 1: match_0.registerSignatureIndex(0); break;
							case 4: match_0.registerSignatureIndex(4); break;
							case 0: match_0.registerSignatureIndex(1); break;
							case 2: match_0.registerSignatureIndex(2); break;
							case 3: match_0.registerSignatureIndex(3); break;
							}
						}
						
						// start search
						start(pac_orchestration, StatelessInputType.PAC, match_0);
					}
				}
				break;
			case "methodsWithCommonAttribute2WithAnotherCommonAttribute_18": 
				{
					var inputMatch = (StatelessDeltaMatch) match;
					if(objs[0] instanceof classDiagram.Clazz)
					if(objs[5] instanceof classDiagram.Attribute)
					if(objs[1] instanceof classDiagram.Clazz)
					if(objs[2] instanceof classDiagram.Method)
					if(objs[3] instanceof classDiagram.Method)
					{
						var match_1 = new StatelessDeltaMatch(msg, "moveFirstCommonAttributeToOtherClass_48", 5, 2, UsingDeltaMode.CREATE);
						match_1.registerInvocationMessage(msg, 1);
						match_1.getNodes()[0] = objs[0];
						match_1.getNodes()[4] = objs[5];
						match_1.getNodes()[1] = objs[1];
						match_1.getNodes()[2] = objs[2];
						match_1.getNodes()[3] = objs[3];
						
						for(var inputSignatureIndex : inputMatch.deltaSignatureBindingIndices) {
							switch(inputSignatureIndex) {
								case 0: break outer;
								case 5: break outer;
								case 1: break outer;
								case 2: break outer;
								case 3: break outer;
							}
						}
						
						// start search
						start(nac_orchestration, StatelessInputType.NAC, match_1);
					}
				}
				break;
			default: throw new RuntimeException("Detected unknown match from " + msg.input.creator);
		}
		
		msg.initialMessage.decrement();
	}
	
	@Override
	protected void addReference(ReferenceAdded msg) {
		initialMessage = msg.initialMessage;
		
		switch(msg.refName) {
		case "classDiagram.Clazz_features_Feature": 
			{
				if(msg.target instanceof classDiagram.Attribute) 
				{
					if(notificationIndex.isNew(msg.source) || notificationIndex.isNew(msg.target))
						break;
						
					var match = new StatelessDeltaMatch(msg, "moveFirstCommonAttributeToOtherClass_48", 5, 2, UsingDeltaMode.CREATE);
					Object[] objs = match.getNodes();
					objs[0] = msg.source;
					objs[4] = msg.target;
					if(options.trackMatchingProcess)
						match.registerDelta(UsingDeltaMode.CREATE, new ModelEdge(msg.source, msg.target, msg.refName));
					match.registerSignatureEdge(0, 4);
					start(edge_explorer_0_orchestration, StatelessInputType.EDGE, match);
				}
			}
			break;
		}
		
		msg.initialMessage.decrement();
	}

	@Override
	protected void removeReference(ReferenceDeleted msg) {
		initialMessage = msg.initialMessage;
		
		switch(msg.refName) {
			case "classDiagram.Clazz_features_Feature": 
		if(msg.target instanceof classDiagram.Attribute) 
		{
			if(notificationIndex.isDeleted(msg.source) || notificationIndex.isDeleted(msg.target))
				break;
							
			var match = new StatelessDeltaMatch(msg, "moveFirstCommonAttributeToOtherClass_48", 5, 2, UsingDeltaMode.DELETE);
			Object[] objs = match.getNodes();
			objs[0] = msg.source;
			objs[4] = msg.target;
			if(options.trackMatchingProcess)
				match.registerDelta(UsingDeltaMode.DELETE, new ModelEdge(msg.source, msg.target, msg.refName));
			match.registerSignatureEdge(0, 4);
			start(edge_explorer_0_orchestration, StatelessInputType.EDGE, match);
		}
		break;
		}
		
		msg.initialMessage.decrement();
	}
	
	@Override
	protected void changeAttribute(AttributeChanged message) {
		initialMessage = message.initialMessage;

		for(Port<?> port : allPorts) {
			message.initialMessage.increment();
			port.forwardMessage(message);
		}
		
		
		message.initialMessage.decrement();
	}
				
	public boolean node_constraint_method(ConstraintCheck constraintCheck) {
		var match = constraintCheck.match();
		Object[] objs = match.getNodes();
		boolean predicate = !objs[0].equals(objs[1]);;
		return predicate;
	}
	
	public boolean node_constraint_0_method(ConstraintCheck constraintCheck) {
		var match = constraintCheck.match();
		Object[] objs = match.getNodes();
		boolean predicate = !objs[3].equals(objs[2]);;
		return predicate;
	}
	
	
	
	@Override
	protected void processMatchRequest(MatchRequest message) {
		initialMessage = message.initialMessage;
		
		var requestNodes = message.input.getNodes();
		
		
		message.initialMessage.decrement();
	}
	
	@Override
	protected boolean checkMatchRequestTypes(MatchRequest request, StatelessDeltaMatch match) {
		var objs = match.getNodes();
		return true;
	}
	
	@Override
	protected StatelessDeltaMatch constructMatchRequestAnswer(MatchRequest request, StatelessDeltaMatch result) {
		initialMessage = request.initialMessage;
		
		var resultNodes = result.getNodes();
		var requestCopy = request.input.copy();
		var requestNodes = requestCopy.getNodes();
		
		
		return requestCopy;
	}
}

