package refactoringcd.full.hipe.engine.actor.stateless;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;

import hipe.engine.actor.Port;
import hipe.engine.util.HiPESet;
import hipe.engine.match.EdgeMatch;
import hipe.engine.match.HMatch;
import hipe.engine.match.OverlapMatch;
import hipe.engine.match.LocalSearchMatch;
import hipe.engine.actor.junction.PortJunction;
import hipe.engine.actor.junction.PortJunctionLeft;
import hipe.engine.actor.junction.PortJunctionRight;
import hipe.engine.message.input.AttributeChanged;
import hipe.engine.message.input.ReferenceAdded;
import hipe.engine.message.input.ReferenceDeleted;
import hipe.engine.message.production.MatchAdded;
import hipe.engine.message.production.MatchDeleted;
import hipe.engine.message.stateless.*;
import hipe.engine.util.CollectionUtil;

import hipe.network.LocalSearchNode;

import hipe.generic.match.GenericJunctionMatch;
import hipe.generic.actor.junction.GenericJunctionActor;
import hipe.generic.actor.local.GenericLocalSearchActor;
import hipe.generic.actor.stateless.*;
import hipe.generic.actor.stateless.enums.*;
import hipe.generic.actor.stateless.search.*;
import hipe.generic.actor.search.misc.*;

import org.eclipse.emf.ecore.EObject;

public class methodsWithCommonAttribute2WithAnotherCommonAttribute_18 extends GenericStatelessSearchActor{
	ConstraintChecker node_constraint;
	ConstraintChecker node_constraint_0;
	ConstraintChecker node_constraint_1;
	DeltaAwareEdgeExplorer edge_explorer;
	DeltaAwareEdgeExplorer edge_explorer_3;
	DeltaAwareEdgeExplorer edge_explorer_4;
	DeltaAwareEdgeExplorer edge_explorer_5;
	DeltaAwareEdgeExplorer edge_explorer_6;
	DeltaAwareEdgeExplorer edge_explorer_7;
	
	SearchOrchestration edge_explorer_0_orchestration;
	SearchOrchestration edge_explorer_1_orchestration;
	SearchOrchestration edge_explorer_2_orchestration;
	SearchOrchestration edge_explorer_3_0_orchestration;
	SearchOrchestration edge_explorer_3_1_orchestration;
	SearchOrchestration edge_explorer_4_0_orchestration;
	SearchOrchestration edge_explorer_4_1_orchestration;
	SearchOrchestration edge_explorer_5_0_orchestration;
	SearchOrchestration edge_explorer_5_1_orchestration;
	SearchOrchestration edge_explorer_6_0_orchestration;
	SearchOrchestration edge_explorer_6_1_orchestration;
	SearchOrchestration edge_explorer_7_0_orchestration;
	
	@Override
	protected void initializeSearchComponents() {
		node_constraint = new ConstraintChecker(this, this::node_constraint_method);
		name2explorer.put("node_constraint", node_constraint);
		node_constraint_0 = new ConstraintChecker(this, this::node_constraint_0_method);
		name2explorer.put("node_constraint_0", node_constraint_0);
		node_constraint_1 = new ConstraintChecker(this, this::node_constraint_1_method);
		name2explorer.put("node_constraint_1", node_constraint_1);
		EdgeLookupMethods edge_explorer_methods = new EdgeLookupMethods();
						edge_explorer_methods.checkSourceType = (o) -> o instanceof classDiagram.Clazz;
						edge_explorer_methods.checkTargetType = (o) -> o instanceof classDiagram.Attribute;
						edge_explorer_methods.multi_lookup = (o) -> ((classDiagram.Clazz) o).getFeatures().stream().filter(obj -> obj instanceof classDiagram.Attribute).collect(Collectors.toList());
						edge_explorer_methods.unique_opposite_lookup = (o) -> {EObject result = ((EObject) o).eContainer(); if(result instanceof classDiagram.Clazz) return edge_explorer_methods.multi_lookup.apply(result).contains(o) ? result : null; else return null;};
						edge_explorer = new DeltaAwareEdgeExplorer(this, 0, 4, edge_explorer_methods, classDiagram.ClassDiagramPackage.eINSTANCE.getClazz_Features());
		name2explorer.put("edge_explorer", edge_explorer);
		EdgeLookupMethods edge_explorer_3_methods = new EdgeLookupMethods();
						edge_explorer_3_methods.checkSourceType = (o) -> o instanceof classDiagram.Clazz;
						edge_explorer_3_methods.checkTargetType = (o) -> o instanceof classDiagram.Attribute;
						edge_explorer_3_methods.multi_lookup = (o) -> ((classDiagram.Clazz) o).getFeatures().stream().filter(obj -> obj instanceof classDiagram.Attribute).collect(Collectors.toList());
						edge_explorer_3_methods.unique_opposite_lookup = (o) -> {EObject result = ((EObject) o).eContainer(); if(result instanceof classDiagram.Clazz) return edge_explorer_3_methods.multi_lookup.apply(result).contains(o) ? result : null; else return null;};
						edge_explorer_3 = new DeltaAwareEdgeExplorer(this, 0, 5, edge_explorer_3_methods, classDiagram.ClassDiagramPackage.eINSTANCE.getClazz_Features());
		name2explorer.put("edge_explorer_3", edge_explorer_3);
		EdgeLookupMethods edge_explorer_4_methods = new EdgeLookupMethods();
						edge_explorer_4_methods.checkSourceType = (o) -> o instanceof classDiagram.Method;
						edge_explorer_4_methods.checkTargetType = (o) -> o instanceof classDiagram.Attribute;
						edge_explorer_4_methods.multi_lookup = (o) -> ((classDiagram.Method) o).getDependencies();
						edge_explorer_4_methods.multi_opposite_lookup = (o) -> (Collection<? extends Object>) ((classDiagram.Attribute) o).eGet(classDiagram.ClassDiagramPackage.eINSTANCE.getMethod_Dependencies().getEOpposite());
						edge_explorer_4 = new DeltaAwareEdgeExplorer(this, 3, 4, edge_explorer_4_methods, classDiagram.ClassDiagramPackage.eINSTANCE.getMethod_Dependencies());
		name2explorer.put("edge_explorer_4", edge_explorer_4);
		EdgeLookupMethods edge_explorer_5_methods = new EdgeLookupMethods();
						edge_explorer_5_methods.checkSourceType = (o) -> o instanceof classDiagram.Method;
						edge_explorer_5_methods.checkTargetType = (o) -> o instanceof classDiagram.Attribute;
						edge_explorer_5_methods.multi_lookup = (o) -> ((classDiagram.Method) o).getDependencies();
						edge_explorer_5_methods.multi_opposite_lookup = (o) -> (Collection<? extends Object>) ((classDiagram.Attribute) o).eGet(classDiagram.ClassDiagramPackage.eINSTANCE.getMethod_Dependencies().getEOpposite());
						edge_explorer_5 = new DeltaAwareEdgeExplorer(this, 2, 4, edge_explorer_5_methods, classDiagram.ClassDiagramPackage.eINSTANCE.getMethod_Dependencies());
		name2explorer.put("edge_explorer_5", edge_explorer_5);
		EdgeLookupMethods edge_explorer_6_methods = new EdgeLookupMethods();
						edge_explorer_6_methods.checkSourceType = (o) -> o instanceof classDiagram.Clazz;
						edge_explorer_6_methods.checkTargetType = (o) -> o instanceof classDiagram.Method;
						edge_explorer_6_methods.multi_lookup = (o) -> ((classDiagram.Clazz) o).getFeatures().stream().filter(obj -> obj instanceof classDiagram.Method).collect(Collectors.toList());
						edge_explorer_6_methods.unique_opposite_lookup = (o) -> {EObject result = ((EObject) o).eContainer(); if(result instanceof classDiagram.Clazz) return edge_explorer_6_methods.multi_lookup.apply(result).contains(o) ? result : null; else return null;};
						edge_explorer_6 = new DeltaAwareEdgeExplorer(this, 1, 3, edge_explorer_6_methods, classDiagram.ClassDiagramPackage.eINSTANCE.getClazz_Features());
		name2explorer.put("edge_explorer_6", edge_explorer_6);
		EdgeLookupMethods edge_explorer_7_methods = new EdgeLookupMethods();
						edge_explorer_7_methods.checkSourceType = (o) -> o instanceof classDiagram.Clazz;
						edge_explorer_7_methods.checkTargetType = (o) -> o instanceof classDiagram.Method;
						edge_explorer_7_methods.multi_lookup = (o) -> ((classDiagram.Clazz) o).getFeatures().stream().filter(obj -> obj instanceof classDiagram.Method).collect(Collectors.toList());
						edge_explorer_7_methods.unique_opposite_lookup = (o) -> {EObject result = ((EObject) o).eContainer(); if(result instanceof classDiagram.Clazz) return edge_explorer_7_methods.multi_lookup.apply(result).contains(o) ? result : null; else return null;};
						edge_explorer_7 = new DeltaAwareEdgeExplorer(this, 1, 2, edge_explorer_7_methods, classDiagram.ClassDiagramPackage.eINSTANCE.getClazz_Features());
		name2explorer.put("edge_explorer_7", edge_explorer_7);
	}
	
	@Override
	protected void initializeOrchestration() {
		edge_explorer_0_orchestration = initializeOrchestration(node.getOrchestrations().get(0).getPlan());
		edge_explorer_1_orchestration = initializeOrchestration(node.getOrchestrations().get(1).getPlan());
		edge_explorer_2_orchestration = initializeOrchestration(node.getOrchestrations().get(2).getPlan());
		edge_explorer_3_0_orchestration = initializeOrchestration(node.getOrchestrations().get(3).getPlan());
		edge_explorer_3_1_orchestration = initializeOrchestration(node.getOrchestrations().get(4).getPlan());
		edge_explorer_4_0_orchestration = initializeOrchestration(node.getOrchestrations().get(5).getPlan());
		edge_explorer_4_1_orchestration = initializeOrchestration(node.getOrchestrations().get(6).getPlan());
		edge_explorer_5_0_orchestration = initializeOrchestration(node.getOrchestrations().get(7).getPlan());
		edge_explorer_5_1_orchestration = initializeOrchestration(node.getOrchestrations().get(8).getPlan());
		edge_explorer_6_0_orchestration = initializeOrchestration(node.getOrchestrations().get(9).getPlan());
		edge_explorer_6_1_orchestration = initializeOrchestration(node.getOrchestrations().get(10).getPlan());
		edge_explorer_7_0_orchestration = initializeOrchestration(node.getOrchestrations().get(11).getPlan());
		
		localNodeOrchestrations = new SearchOrchestration[2];
		localNodeOrchestrations[0] = initializeOrchestration(node.getLocalNodeOrchestration().get(0).getPlan());
		localNodeOrchestrations[1] = initializeOrchestration(node.getLocalNodeOrchestration().get(1).getPlan());
	}
	
	@Override
	protected void added(MatchAdded<HMatch> msg) {
		initialMessage = msg.initialMessage;

		HMatch match = msg.input;
		Object[] objs = match.getNodes();
		outer: switch(match.creator) {
			case "Clazz_object_SP0": 
				{
					{
						// fromClazz
						var match_0 = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.CREATE);
						match_0.getNodes()[0] = objs[0];
						match_0.registerSignatureIndex(0);
						if(options.trackMatchingProcess)
							match_0.registerDelta(UsingDeltaMode.CREATE, objs[0]);
						start(edge_explorer_1_orchestration, StatelessInputType.OBJECT, match_0);
					}
					{
						// toClazz
						var match_1 = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.CREATE);
						match_1.getNodes()[1] = objs[0];
						match_1.registerSignatureIndex(1);
						if(options.trackMatchingProcess)
							match_1.registerDelta(UsingDeltaMode.CREATE, objs[0]);
						start(edge_explorer_6_1_orchestration, StatelessInputType.OBJECT, match_1);
					}
				}
				break;
			case "Method_object_SP0": 
				{
					{
						// fromMethod
						var match_2 = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.CREATE);
						match_2.getNodes()[2] = objs[0];
						match_2.registerSignatureIndex(2);
						if(options.trackMatchingProcess)
							match_2.registerDelta(UsingDeltaMode.CREATE, objs[0]);
						start(edge_explorer_5_1_orchestration, StatelessInputType.OBJECT, match_2);
					}
					{
						// toMethod
						var match_3 = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.CREATE);
						match_3.getNodes()[3] = objs[0];
						match_3.registerSignatureIndex(3);
						if(options.trackMatchingProcess)
							match_3.registerDelta(UsingDeltaMode.CREATE, objs[0]);
						start(edge_explorer_4_1_orchestration, StatelessInputType.OBJECT, match_3);
					}
				}
				break;
			case "Attribute_object_SP0": 
				{
					{
						// commonAttribute
						var match_4 = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.CREATE);
						match_4.getNodes()[4] = objs[0];
						match_4.registerSignatureIndex(4);
						if(options.trackMatchingProcess)
							match_4.registerDelta(UsingDeltaMode.CREATE, objs[0]);
						start(edge_explorer_2_orchestration, StatelessInputType.OBJECT, match_4);
					}
					{
						// otherAttribute
						var match_5 = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.CREATE);
						match_5.getNodes()[5] = objs[0];
						match_5.registerSignatureIndex(5);
						if(options.trackMatchingProcess)
							match_5.registerDelta(UsingDeltaMode.CREATE, objs[0]);
						start(edge_explorer_3_1_orchestration, StatelessInputType.OBJECT, match_5);
					}
				}
				break;
			default: throw new RuntimeException("Detected unknown match from " + msg.input.creator);
		}
		
		msg.initialMessage.decrement();
	}

	@Override
	protected void removed(MatchDeleted<HMatch> msg) {
		initialMessage = msg.initialMessage;

		HMatch match = msg.input;
		Object[] objs = match.getNodes();

		outer: switch(match.creator) {
			case "Clazz_object_SP0": 
				{
					{
						// fromClazz
						var match_0 = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.DELETE);
						match_0.getNodes()[0] = objs[0];
						match_0.registerSignatureIndex(0);
						if(options.trackMatchingProcess)
							match_0.registerDelta(UsingDeltaMode.DELETE, objs[0]);
						start(edge_explorer_1_orchestration, StatelessInputType.OBJECT, match_0);
					}
					{
						// toClazz
						var match_1 = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.DELETE);
						match_1.getNodes()[1] = objs[0];
						match_1.registerSignatureIndex(1);
						if(options.trackMatchingProcess)
							match_1.registerDelta(UsingDeltaMode.DELETE, objs[0]);
						start(edge_explorer_6_1_orchestration, StatelessInputType.OBJECT, match_1);
					}
				}
				break;
			case "Method_object_SP0": 
				{
					{
						// fromMethod
						var match_2 = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.DELETE);
						match_2.getNodes()[2] = objs[0];
						match_2.registerSignatureIndex(2);
						if(options.trackMatchingProcess)
							match_2.registerDelta(UsingDeltaMode.DELETE, objs[0]);
						start(edge_explorer_5_1_orchestration, StatelessInputType.OBJECT, match_2);
					}
					{
						// toMethod
						var match_3 = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.DELETE);
						match_3.getNodes()[3] = objs[0];
						match_3.registerSignatureIndex(3);
						if(options.trackMatchingProcess)
							match_3.registerDelta(UsingDeltaMode.DELETE, objs[0]);
						start(edge_explorer_4_1_orchestration, StatelessInputType.OBJECT, match_3);
					}
				}
				break;
			case "Attribute_object_SP0": 
				{
					{
						// commonAttribute
						var match_4 = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.DELETE);
						match_4.getNodes()[4] = objs[0];
						match_4.registerSignatureIndex(4);
						if(options.trackMatchingProcess)
							match_4.registerDelta(UsingDeltaMode.DELETE, objs[0]);
						start(edge_explorer_2_orchestration, StatelessInputType.OBJECT, match_4);
					}
					{
						// otherAttribute
						var match_5 = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.DELETE);
						match_5.getNodes()[5] = objs[0];
						match_5.registerSignatureIndex(5);
						if(options.trackMatchingProcess)
							match_5.registerDelta(UsingDeltaMode.DELETE, objs[0]);
						start(edge_explorer_3_1_orchestration, StatelessInputType.OBJECT, match_5);
					}
				}
				break;
			default: throw new RuntimeException("Detected unknown match from " + msg.input.creator);
		}
		
		msg.initialMessage.decrement();
	}
	
	@Override
	protected void addReference(ReferenceAdded msg) {
		initialMessage = msg.initialMessage;
		
		switch(msg.refName) {
		case "classDiagram.Clazz_features_Feature": 
			{
				if(msg.target instanceof classDiagram.Attribute) 
				{
					if(notificationIndex.isNew(msg.source) || notificationIndex.isNew(msg.target))
						break;
						
					var match = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.CREATE);
					Object[] objs = match.getNodes();
					objs[0] = msg.source;
					objs[4] = msg.target;
					if(options.trackMatchingProcess)
						match.registerDelta(UsingDeltaMode.CREATE, new ModelEdge(msg.source, msg.target, msg.refName));
					match.registerSignatureEdge(0, 4);
					start(edge_explorer_0_orchestration, StatelessInputType.EDGE, match);
				}
				if(msg.target instanceof classDiagram.Attribute) 
				{
					if(notificationIndex.isNew(msg.source) || notificationIndex.isNew(msg.target))
						break;
						
					var match = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.CREATE);
					Object[] objs = match.getNodes();
					objs[0] = msg.source;
					objs[5] = msg.target;
					if(options.trackMatchingProcess)
						match.registerDelta(UsingDeltaMode.CREATE, new ModelEdge(msg.source, msg.target, msg.refName));
					match.registerSignatureEdge(0, 5);
					start(edge_explorer_3_0_orchestration, StatelessInputType.EDGE, match);
				}
				if(msg.target instanceof classDiagram.Method) 
				{
					if(notificationIndex.isNew(msg.source) || notificationIndex.isNew(msg.target))
						break;
						
					var match = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.CREATE);
					Object[] objs = match.getNodes();
					objs[1] = msg.source;
					objs[3] = msg.target;
					if(options.trackMatchingProcess)
						match.registerDelta(UsingDeltaMode.CREATE, new ModelEdge(msg.source, msg.target, msg.refName));
					match.registerSignatureEdge(1, 3);
					start(edge_explorer_6_0_orchestration, StatelessInputType.EDGE, match);
				}
				if(msg.target instanceof classDiagram.Method) 
				{
					if(notificationIndex.isNew(msg.source) || notificationIndex.isNew(msg.target))
						break;
						
					var match = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.CREATE);
					Object[] objs = match.getNodes();
					objs[1] = msg.source;
					objs[2] = msg.target;
					if(options.trackMatchingProcess)
						match.registerDelta(UsingDeltaMode.CREATE, new ModelEdge(msg.source, msg.target, msg.refName));
					match.registerSignatureEdge(1, 2);
					start(edge_explorer_7_0_orchestration, StatelessInputType.EDGE, match);
				}
			}
			break;
		case "classDiagram.Method_dependencies_Attribute": 
			{
				{
					if(notificationIndex.isNew(msg.source) || notificationIndex.isNew(msg.target))
						break;
						
					var match = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.CREATE);
					Object[] objs = match.getNodes();
					objs[3] = msg.source;
					objs[4] = msg.target;
					if(options.trackMatchingProcess)
						match.registerDelta(UsingDeltaMode.CREATE, new ModelEdge(msg.source, msg.target, msg.refName));
					match.registerSignatureEdge(3, 4);
					start(edge_explorer_4_0_orchestration, StatelessInputType.EDGE, match);
				}
				{
					if(notificationIndex.isNew(msg.source) || notificationIndex.isNew(msg.target))
						break;
						
					var match = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.CREATE);
					Object[] objs = match.getNodes();
					objs[2] = msg.source;
					objs[4] = msg.target;
					if(options.trackMatchingProcess)
						match.registerDelta(UsingDeltaMode.CREATE, new ModelEdge(msg.source, msg.target, msg.refName));
					match.registerSignatureEdge(2, 4);
					start(edge_explorer_5_0_orchestration, StatelessInputType.EDGE, match);
				}
			}
			break;
		}
		
		msg.initialMessage.decrement();
	}

	@Override
	protected void removeReference(ReferenceDeleted msg) {
		initialMessage = msg.initialMessage;
		
		switch(msg.refName) {
			case "classDiagram.Clazz_features_Feature": 
		if(msg.target instanceof classDiagram.Attribute) 
		{
			if(notificationIndex.isDeleted(msg.source) || notificationIndex.isDeleted(msg.target))
				break;
							
			var match = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.DELETE);
			Object[] objs = match.getNodes();
			objs[0] = msg.source;
			objs[4] = msg.target;
			if(options.trackMatchingProcess)
				match.registerDelta(UsingDeltaMode.DELETE, new ModelEdge(msg.source, msg.target, msg.refName));
			match.registerSignatureEdge(0, 4);
			start(edge_explorer_0_orchestration, StatelessInputType.EDGE, match);
		}
		if(msg.target instanceof classDiagram.Attribute) 
		{
			if(notificationIndex.isDeleted(msg.source) || notificationIndex.isDeleted(msg.target))
				break;
							
			var match = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.DELETE);
			Object[] objs = match.getNodes();
			objs[0] = msg.source;
			objs[5] = msg.target;
			if(options.trackMatchingProcess)
				match.registerDelta(UsingDeltaMode.DELETE, new ModelEdge(msg.source, msg.target, msg.refName));
			match.registerSignatureEdge(0, 5);
			start(edge_explorer_3_0_orchestration, StatelessInputType.EDGE, match);
		}
		if(msg.target instanceof classDiagram.Method) 
		{
			if(notificationIndex.isDeleted(msg.source) || notificationIndex.isDeleted(msg.target))
				break;
							
			var match = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.DELETE);
			Object[] objs = match.getNodes();
			objs[1] = msg.source;
			objs[3] = msg.target;
			if(options.trackMatchingProcess)
				match.registerDelta(UsingDeltaMode.DELETE, new ModelEdge(msg.source, msg.target, msg.refName));
			match.registerSignatureEdge(1, 3);
			start(edge_explorer_6_0_orchestration, StatelessInputType.EDGE, match);
		}
		if(msg.target instanceof classDiagram.Method) 
		{
			if(notificationIndex.isDeleted(msg.source) || notificationIndex.isDeleted(msg.target))
				break;
							
			var match = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.DELETE);
			Object[] objs = match.getNodes();
			objs[1] = msg.source;
			objs[2] = msg.target;
			if(options.trackMatchingProcess)
				match.registerDelta(UsingDeltaMode.DELETE, new ModelEdge(msg.source, msg.target, msg.refName));
			match.registerSignatureEdge(1, 2);
			start(edge_explorer_7_0_orchestration, StatelessInputType.EDGE, match);
		}
		break;
			case "classDiagram.Method_dependencies_Attribute": 
		{
			if(notificationIndex.isDeleted(msg.source) || notificationIndex.isDeleted(msg.target))
				break;
							
			var match = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.DELETE);
			Object[] objs = match.getNodes();
			objs[3] = msg.source;
			objs[4] = msg.target;
			if(options.trackMatchingProcess)
				match.registerDelta(UsingDeltaMode.DELETE, new ModelEdge(msg.source, msg.target, msg.refName));
			match.registerSignatureEdge(3, 4);
			start(edge_explorer_4_0_orchestration, StatelessInputType.EDGE, match);
		}
		{
			if(notificationIndex.isDeleted(msg.source) || notificationIndex.isDeleted(msg.target))
				break;
							
			var match = new StatelessDeltaMatch(msg, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, UsingDeltaMode.DELETE);
			Object[] objs = match.getNodes();
			objs[2] = msg.source;
			objs[4] = msg.target;
			if(options.trackMatchingProcess)
				match.registerDelta(UsingDeltaMode.DELETE, new ModelEdge(msg.source, msg.target, msg.refName));
			match.registerSignatureEdge(2, 4);
			start(edge_explorer_5_0_orchestration, StatelessInputType.EDGE, match);
		}
		break;
		}
		
		msg.initialMessage.decrement();
	}
	
	@Override
	protected void changeAttribute(AttributeChanged message) {
		initialMessage = message.initialMessage;

		for(Port<?> port : allPorts) {
			message.initialMessage.increment();
			port.forwardMessage(message);
		}
		
		
		message.initialMessage.decrement();
	}
				
	public boolean node_constraint_method(ConstraintCheck constraintCheck) {
		var match = constraintCheck.match();
		Object[] objs = match.getNodes();
		boolean predicate = !objs[1].equals(objs[0]);;
		return predicate;
	}
	
	public boolean node_constraint_0_method(ConstraintCheck constraintCheck) {
		var match = constraintCheck.match();
		Object[] objs = match.getNodes();
		boolean predicate = !objs[2].equals(objs[3]);;
		return predicate;
	}
	
	public boolean node_constraint_1_method(ConstraintCheck constraintCheck) {
		var match = constraintCheck.match();
		Object[] objs = match.getNodes();
		boolean predicate = !objs[5].equals(objs[4]);;
		return predicate;
	}
	
	
	
	@Override
	protected void processMatchRequest(MatchRequest message) {
		initialMessage = message.initialMessage;
		
		var requestNodes = message.input.getNodes();
		
		switch(message.nodeName) {
			case "moveFirstCommonAttributeToOtherClass_48": {
				switch(message.queryComponentId) {
					case 1: {
						var deltaMatch = new StatelessDeltaMatch(message, "methodsWithCommonAttribute2WithAnotherCommonAttribute_18", 6, 0, message.usedDelta);
						var nodes = deltaMatch.getNodes();
						var lastFoundIndex = -1;
						
						nodes[0] = requestNodes[0];
						if(nodes[0] != null) 
							lastFoundIndex = 0;
						nodes[5] = requestNodes[4];
						if(nodes[5] != null) 
							lastFoundIndex = 5;
						nodes[1] = requestNodes[1];
						if(nodes[1] != null) 
							lastFoundIndex = 1;
						nodes[2] = requestNodes[2];
						if(nodes[2] != null) 
							lastFoundIndex = 2;
						nodes[3] = requestNodes[3];
						if(nodes[3] != null) 
							lastFoundIndex = 3;
						
						switch(lastFoundIndex) {
							case 0: 
								startFromRequest(edge_explorer_1_orchestration, StatelessInputType.REQUEST , deltaMatch, message);
								break;
							case 5: 
								startFromRequest(edge_explorer_3_1_orchestration, StatelessInputType.REQUEST , deltaMatch, message);
								break;
							case 1: 
								startFromRequest(edge_explorer_6_1_orchestration, StatelessInputType.REQUEST , deltaMatch, message);
								break;
							case 2: 
								startFromRequest(edge_explorer_5_1_orchestration, StatelessInputType.REQUEST , deltaMatch, message);
								break;
							case 3: 
								startFromRequest(edge_explorer_4_1_orchestration, StatelessInputType.REQUEST , deltaMatch, message);
								break;
							default: throw new RuntimeException("Cannot execute request due to missing node information");
						}
						break;
					}
				}
				break;
			}
		}
		
		message.initialMessage.decrement();
	}
	
	@Override
	protected boolean checkMatchRequestTypes(MatchRequest request, StatelessDeltaMatch match) {
		var objs = match.getNodes();
		switch(request.nodeName) {
			case "moveFirstCommonAttributeToOtherClass_48": {
				switch(request.queryComponentId) {
					case 1: {
						if(!(objs[0] instanceof classDiagram.Clazz))
							return false;
						if(!(objs[5] instanceof classDiagram.Attribute))
							return false;
						if(!(objs[1] instanceof classDiagram.Clazz))
							return false;
						if(!(objs[2] instanceof classDiagram.Method))
							return false;
						if(!(objs[3] instanceof classDiagram.Method))
							return false;
						break;
					}
				}
				break;
			}
		}
		return true;
	}
	
	@Override
	protected StatelessDeltaMatch constructMatchRequestAnswer(MatchRequest request, StatelessDeltaMatch result) {
		initialMessage = request.initialMessage;
		
		var resultNodes = result.getNodes();
		var requestCopy = request.input.copy();
		var requestNodes = requestCopy.getNodes();
		
		switch(request.input.creator) {
			case "moveFirstCommonAttributeToOtherClass_48": {
				switch(request.queryComponentId) {
					case 1: {
						requestNodes[0] = resultNodes[0];
						requestNodes[4] = resultNodes[5];
						requestNodes[1] = resultNodes[1];
						requestNodes[2] = resultNodes[2];
						requestNodes[3] = resultNodes[3];
						break;
					}
				}
				break;
			}
			default: throw new RuntimeException("Could not create match request answer due to unknown sender: " + request.input.creator);
		}
		
		return requestCopy;
	}
}

