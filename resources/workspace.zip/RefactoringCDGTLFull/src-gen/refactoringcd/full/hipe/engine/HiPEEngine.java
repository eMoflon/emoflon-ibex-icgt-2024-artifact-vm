package refactoringcd.full.hipe.engine;

import akka.actor.ActorRef;
import akka.actor.Props;

import refactoringcd.full.hipe.engine.actor.NotificationActor;
import refactoringcd.full.hipe.engine.actor.DispatchActor;
import refactoringcd.full.hipe.engine.actor.stateless.intactMethodAttributeDependency_1;
import refactoringcd.full.hipe.engine.actor.stateless.methodsWithCommonAttribute_6;
import refactoringcd.full.hipe.engine.actor.stateless.methodsWithCommonAttribute2_12;
import refactoringcd.full.hipe.engine.actor.stateless.methodsWithCommonAttribute2WithAnotherCommonAttribute_18;
import refactoringcd.full.hipe.engine.actor.stateless.methodsWithCommonAttribute3_25;
import refactoringcd.full.hipe.engine.actor.stateless.methodsWithCommonAttribute4_31;
import refactoringcd.full.hipe.engine.actor.stateless.methodsWithOtherCommonAttribute4_37;
import refactoringcd.full.hipe.engine.actor.stateless.moveAttribute_44;
import refactoringcd.full.hipe.engine.actor.stateless.moveFirstCommonAttributeToOtherClass_48;
import refactoringcd.full.hipe.engine.actor.stateless.moveLastCommonAttributeToOtherClass_49;
import refactoringcd.full.hipe.engine.actor.stateless.moveMethod_50;
import refactoringcd.full.hipe.engine.actor.stateless.movingMethodToOtherMethodWithCommonDependency_54;
import refactoringcd.full.hipe.engine.actor.stateless.movingMethodToOtherMethodWithoutCommonDependency_59;
import refactoringcd.full.hipe.engine.actor.stateless.movingMethodWithAttributeDependencyTogether_64;

import hipe.engine.IHiPEEngine;
import hipe.engine.message.InitGenReferenceActor;

import hipe.generic.actor.GenericObjectActor;
import hipe.generic.actor.GenericReferenceActor;
import hipe.generic.actor.GenericProductionActor;
import hipe.generic.actor.junction.*;
import hipe.engine.HiPEOptions;

import hipe.network.*;

public class HiPEEngine extends IHiPEEngine{
	
	public HiPEEngine(HiPENetwork network) {
		super(network);
	}
	
	public HiPEEngine() {
		super();
	}
	
	@Override
	public String getClassLocation() {
		return getClass().getProtectionDomain().getCodeSource().getLocation().getPath().toString();
	}
	
	@Override
	public String getPackageName() {
		return getClass().getPackageName();
	}
	
	@Override
	protected ActorRef getDispatchActor() {
		return system.actorOf(
			Props.create(DispatchActor.class, () -> new DispatchActor(name2actor, incUtil)),
			"DispatchActor");
	}
	
	@Override
	protected ActorRef getNotificationActor(HiPEOptions options) {
		return system.actorOf(
			Props.create(NotificationActor.class, () -> new NotificationActor(dispatcher, incUtil, notificationIndex, options)), 
			"NotificationActor");
	}
	
	@Override
	public void createProductionNodes() {
		classes.put("intactMethodAttributeDependency_production", GenericProductionActor.class);
		productionNodes2pattern.put("intactMethodAttributeDependency_production", "intactMethodAttributeDependency");
		classes.put("methodsWithCommonAttribute_production", GenericProductionActor.class);
		productionNodes2pattern.put("methodsWithCommonAttribute_production", "methodsWithCommonAttribute");
		classes.put("methodsWithCommonAttribute2_production", GenericProductionActor.class);
		productionNodes2pattern.put("methodsWithCommonAttribute2_production", "methodsWithCommonAttribute2");
		classes.put("methodsWithCommonAttribute2WithAnotherCommonAttribute_production", GenericProductionActor.class);
		productionNodes2pattern.put("methodsWithCommonAttribute2WithAnotherCommonAttribute_production", "methodsWithCommonAttribute2WithAnotherCommonAttribute");
		classes.put("methodsWithCommonAttribute3_production", GenericProductionActor.class);
		productionNodes2pattern.put("methodsWithCommonAttribute3_production", "methodsWithCommonAttribute3");
		classes.put("methodsWithCommonAttribute4_production", GenericProductionActor.class);
		productionNodes2pattern.put("methodsWithCommonAttribute4_production", "methodsWithCommonAttribute4");
		classes.put("methodsWithOtherCommonAttribute4_production", GenericProductionActor.class);
		productionNodes2pattern.put("methodsWithOtherCommonAttribute4_production", "methodsWithOtherCommonAttribute4");
		classes.put("moveAttribute_production", GenericProductionActor.class);
		productionNodes2pattern.put("moveAttribute_production", "moveAttribute");
		classes.put("moveFirstCommonAttributeToOtherClass_production", GenericProductionActor.class);
		productionNodes2pattern.put("moveFirstCommonAttributeToOtherClass_production", "moveFirstCommonAttributeToOtherClass");
		classes.put("moveLastCommonAttributeToOtherClass_production", GenericProductionActor.class);
		productionNodes2pattern.put("moveLastCommonAttributeToOtherClass_production", "moveLastCommonAttributeToOtherClass");
		classes.put("moveMethod_production", GenericProductionActor.class);
		productionNodes2pattern.put("moveMethod_production", "moveMethod");
		classes.put("movingMethodToOtherMethodWithCommonDependency_production", GenericProductionActor.class);
		productionNodes2pattern.put("movingMethodToOtherMethodWithCommonDependency_production", "movingMethodToOtherMethodWithCommonDependency");
		classes.put("movingMethodToOtherMethodWithoutCommonDependency_production", GenericProductionActor.class);
		productionNodes2pattern.put("movingMethodToOtherMethodWithoutCommonDependency_production", "movingMethodToOtherMethodWithoutCommonDependency");
		classes.put("movingMethodWithAttributeDependencyTogether_production", GenericProductionActor.class);
		productionNodes2pattern.put("movingMethodWithAttributeDependencyTogether_production", "movingMethodWithAttributeDependencyTogether");
		
	}
	
	@Override
	public void createJunctionNodes() {
		classes.put("intactMethodAttributeDependency_1", intactMethodAttributeDependency_1.class);
		classes.put("methodsWithCommonAttribute_6", methodsWithCommonAttribute_6.class);
		classes.put("methodsWithCommonAttribute2_12", methodsWithCommonAttribute2_12.class);
		classes.put("methodsWithCommonAttribute2WithAnotherCommonAttribute_18", methodsWithCommonAttribute2WithAnotherCommonAttribute_18.class);
		classes.put("methodsWithCommonAttribute3_25", methodsWithCommonAttribute3_25.class);
		classes.put("methodsWithCommonAttribute4_31", methodsWithCommonAttribute4_31.class);
		classes.put("methodsWithOtherCommonAttribute4_37", methodsWithOtherCommonAttribute4_37.class);
		classes.put("moveAttribute_44", moveAttribute_44.class);
		classes.put("moveFirstCommonAttributeToOtherClass_48", moveFirstCommonAttributeToOtherClass_48.class);
		classes.put("moveLastCommonAttributeToOtherClass_49", moveLastCommonAttributeToOtherClass_49.class);
		classes.put("moveMethod_50", moveMethod_50.class);
		classes.put("movingMethodToOtherMethodWithCommonDependency_54", movingMethodToOtherMethodWithCommonDependency_54.class);
		classes.put("movingMethodToOtherMethodWithoutCommonDependency_59", movingMethodToOtherMethodWithoutCommonDependency_59.class);
		classes.put("movingMethodWithAttributeDependencyTogether_64", movingMethodWithAttributeDependencyTogether_64.class);
	}
	
	@Override
	public void createReferenceNodes() {
		
	}
	
	@Override
	public void createObjectNodes() {
		classes.put("Clazz_object_SP0",Clazz_object_SP0.class);
		classes.put("Clazz_object_SP1",Clazz_object_SP1.class);
		classes.put("Clazz_object_SP2",Clazz_object_SP2.class);
		classes.put("Method_object_SP0",Method_object_SP0.class);
		classes.put("Method_object_SP1",Method_object_SP1.class);
		classes.put("Method_object_SP2",Method_object_SP2.class);
		classes.put("Attribute_object_SP0",Attribute_object_SP0.class);
		classes.put("Attribute_object_SP1",Attribute_object_SP1.class);
		classes.put("Attribute_object_SP2",Attribute_object_SP2.class);
		
	}
	
	@Override
	public void initializeReferenceNodes() {
	}
}

class Clazz_object_SP0 extends GenericObjectActor<classDiagram.Clazz> { }
class Clazz_object_SP1 extends GenericObjectActor<classDiagram.Clazz> { }
class Clazz_object_SP2 extends GenericObjectActor<classDiagram.Clazz> { }
class Method_object_SP0 extends GenericObjectActor<classDiagram.Method> { }
class Method_object_SP1 extends GenericObjectActor<classDiagram.Method> { }
class Method_object_SP2 extends GenericObjectActor<classDiagram.Method> { }
class Attribute_object_SP0 extends GenericObjectActor<classDiagram.Attribute> { }
class Attribute_object_SP1 extends GenericObjectActor<classDiagram.Attribute> { }
class Attribute_object_SP2 extends GenericObjectActor<classDiagram.Attribute> { }


