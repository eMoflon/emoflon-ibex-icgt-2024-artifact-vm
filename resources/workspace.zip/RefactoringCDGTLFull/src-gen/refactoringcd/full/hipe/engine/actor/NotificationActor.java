package refactoringcd.full.hipe.engine.actor;

import java.util.Collection;
import java.util.LinkedList;

import org.eclipse.emf.ecore.EObject;

import akka.actor.ActorRef;

import hipe.engine.HiPEOptions;
import hipe.generic.actor.GenericNotificationActor;
import hipe.engine.util.IncUtil;
import hipe.engine.util.notifications.DeltaNotificationIndex;

public class NotificationActor extends GenericNotificationActor {
	
	public NotificationActor(ActorRef dispatchActor, IncUtil incUtil, DeltaNotificationIndex notificationIndex, HiPEOptions options) {
		super(dispatchActor, incUtil, notificationIndex, options);
	}
	
	@Override
	protected void initializeExploration() {
		explorationConsumer.put(classDiagram.ClassDiagramPackage.eINSTANCE.getMethod(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(classDiagram.ClassDiagramPackage.eINSTANCE.getClazzModel(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			classDiagram.ClazzModel _clazzmodel = (classDiagram.ClazzModel) obj;
			children.addAll(_clazzmodel.getClazzes());
			return children;
		});
		explorationConsumer.put(classDiagram.ClassDiagramPackage.eINSTANCE.getAttribute(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(classDiagram.ClassDiagramPackage.eINSTANCE.getFeature(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(classDiagram.ClassDiagramPackage.eINSTANCE.getClazz(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			classDiagram.Clazz _clazz = (classDiagram.Clazz) obj;
			children.addAll(_clazz.getFeatures());
			return children;
		});
	}
}

