package refactoringcd.full.hipe.engine.actor;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EObject;

import java.text.DecimalFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.stream.ActorMaterializer;
import akka.stream.javadsl.*;
import static akka.pattern.Patterns.ask;

import hipe.engine.util.CollectionUtil;
import hipe.engine.util.IncUtil;
import hipe.engine.message.NewInput;
import hipe.engine.message.NoMoreInput;
import hipe.engine.message.input.ObjectAdded;
import hipe.engine.message.input.ObjectDeleted;
import hipe.engine.message.input.ReferenceAdded;
import hipe.engine.message.input.ReferenceDeleted;		
import hipe.engine.message.input.AttributeChanged;
import hipe.engine.message.input.NotificationContainer;

import hipe.generic.actor.junction.util.HiPEConfig;

public class DispatchActor extends AbstractActor {
	
	private int counter = 0;
	public long time = 0;
				
	private Map<String, ActorRef> name2actor;
	
	private Map<Object, Consumer<Object>> type2addConsumer = CollectionUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2setConsumer = CollectionUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2addEdgeConsumer = CollectionUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2removeEdgeConsumer = CollectionUtil.createMap();
	
	private IncUtil incUtil;
	
	private ActorMaterializer materializer;
	
	public DispatchActor(Map<String, ActorRef> name2actor, IncUtil incUtil) {
		this.name2actor = name2actor;
		this.incUtil = incUtil;
		
		initializeAdd();
		initializeSet();
		initializeAddEdge();
		initializeRemoveEdge();
	
		materializer = ActorMaterializer.create(getContext());
	}
	
	private void initializeAdd() {
		type2addConsumer.put(classDiagram.ClassDiagramPackage.eINSTANCE.getMethod(), obj -> {
			classDiagram.Method _method = (classDiagram.Method) obj;
			incUtil.newMessage();
			name2actor.get("Method_object_SP0").tell(new ObjectAdded<classDiagram.Method>(incUtil, _method), getSelf());
			incUtil.newMessage();
			name2actor.get("Method_object_SP1").tell(new ObjectAdded<classDiagram.Method>(incUtil, _method), getSelf());
			incUtil.newMessage();
			name2actor.get("Method_object_SP2").tell(new ObjectAdded<classDiagram.Method>(incUtil, _method), getSelf());
		});
		type2addConsumer.put(classDiagram.ClassDiagramPackage.eINSTANCE.getAttribute(), obj -> {
			classDiagram.Attribute _attribute = (classDiagram.Attribute) obj;
			incUtil.newMessage();
			name2actor.get("Attribute_object_SP0").tell(new ObjectAdded<classDiagram.Attribute>(incUtil, _attribute), getSelf());
			incUtil.newMessage();
			name2actor.get("Attribute_object_SP1").tell(new ObjectAdded<classDiagram.Attribute>(incUtil, _attribute), getSelf());
			incUtil.newMessage();
			name2actor.get("Attribute_object_SP2").tell(new ObjectAdded<classDiagram.Attribute>(incUtil, _attribute), getSelf());
		});
		type2addConsumer.put(classDiagram.ClassDiagramPackage.eINSTANCE.getClazz(), obj -> {
			classDiagram.Clazz _clazz = (classDiagram.Clazz) obj;
			incUtil.newMessage();
			name2actor.get("Clazz_object_SP0").tell(new ObjectAdded<classDiagram.Clazz>(incUtil, _clazz), getSelf());
			incUtil.newMessage();
			name2actor.get("Clazz_object_SP1").tell(new ObjectAdded<classDiagram.Clazz>(incUtil, _clazz), getSelf());
			incUtil.newMessage();
			name2actor.get("Clazz_object_SP2").tell(new ObjectAdded<classDiagram.Clazz>(incUtil, _clazz), getSelf());
		});
	}
	
	private void initializeSet() {
	}
	
	private void initializeAddEdge() {
		feature2addEdgeConsumer.put(classDiagram.ClassDiagramPackage.eINSTANCE.getMethod_Dependencies(), notification -> {
			incUtil.newMessage();
			name2actor.get("intactMethodAttributeDependency_1").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute_6").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute_6").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2_12").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2_12").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute3_25").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute3_25").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute4_31").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute4_31").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithOtherCommonAttribute4_37").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithOtherCommonAttribute4_37").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodWithAttributeDependencyTogether_64").tell(new ReferenceAdded<classDiagram.Method, classDiagram.Attribute>(incUtil,(classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getNewValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
		});
		feature2addEdgeConsumer.put(classDiagram.ClassDiagramPackage.eINSTANCE.getClazz_Features(), notification -> {
			incUtil.newMessage();
			name2actor.get("intactMethodAttributeDependency_1").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("intactMethodAttributeDependency_1").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute_6").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute_6").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute_6").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2_12").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2_12").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2_12").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute3_25").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute3_25").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute3_25").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute4_31").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute4_31").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute4_31").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithOtherCommonAttribute4_37").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithOtherCommonAttribute4_37").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithOtherCommonAttribute4_37").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithOtherCommonAttribute4_37").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("moveAttribute_44").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("moveFirstCommonAttributeToOtherClass_48").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("moveMethod_50").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodToOtherMethodWithCommonDependency_54").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodToOtherMethodWithCommonDependency_54").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodToOtherMethodWithoutCommonDependency_59").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodToOtherMethodWithoutCommonDependency_59").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodWithAttributeDependencyTogether_64").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodWithAttributeDependencyTogether_64").tell(new ReferenceAdded<classDiagram.Clazz, classDiagram.Feature>(incUtil,(classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getNewValue(), "classDiagram.Clazz_features_Feature"), getSelf());
		});
	}
	
	private void initializeRemoveEdge() {
		feature2removeEdgeConsumer.put(classDiagram.ClassDiagramPackage.eINSTANCE.getMethod_Dependencies(), notification -> {
			incUtil.newMessage();
			name2actor.get("intactMethodAttributeDependency_1").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute_6").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute_6").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2_12").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2_12").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute3_25").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute3_25").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute4_31").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute4_31").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithOtherCommonAttribute4_37").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithOtherCommonAttribute4_37").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodWithAttributeDependencyTogether_64").tell(new ReferenceDeleted<classDiagram.Method, classDiagram.Attribute>(incUtil, (classDiagram.Method) notification.getNotifier(), (classDiagram.Attribute) notification.getOldValue(), "classDiagram.Method_dependencies_Attribute"), getSelf());
		});
		feature2removeEdgeConsumer.put(classDiagram.ClassDiagramPackage.eINSTANCE.getClazz_Features(), notification -> {
			incUtil.newMessage();
			name2actor.get("intactMethodAttributeDependency_1").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("intactMethodAttributeDependency_1").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute_6").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute_6").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute_6").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2_12").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2_12").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2_12").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute2WithAnotherCommonAttribute_18").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute3_25").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute3_25").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute3_25").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute4_31").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute4_31").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithCommonAttribute4_31").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithOtherCommonAttribute4_37").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithOtherCommonAttribute4_37").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithOtherCommonAttribute4_37").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("methodsWithOtherCommonAttribute4_37").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("moveAttribute_44").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("moveFirstCommonAttributeToOtherClass_48").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("moveMethod_50").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodToOtherMethodWithCommonDependency_54").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodToOtherMethodWithCommonDependency_54").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodToOtherMethodWithoutCommonDependency_59").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodToOtherMethodWithoutCommonDependency_59").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodWithAttributeDependencyTogether_64").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
			incUtil.newMessage();
			name2actor.get("movingMethodWithAttributeDependencyTogether_64").tell(new ReferenceDeleted<classDiagram.Clazz, classDiagram.Feature>(incUtil, (classDiagram.Clazz) notification.getNotifier(), (classDiagram.Feature) notification.getOldValue(), "classDiagram.Clazz_features_Feature"), getSelf());
		});
	}

	@Override
	public void preStart() throws Exception {
		super.preStart();
	}

	@Override
	public void postStop() throws Exception {
		if(HiPEConfig.logWorkloadActivated) {
			DecimalFormat df = new DecimalFormat("0.#####");
	        df.setMaximumFractionDigits(5);
			System.err.println("DispatchNode" + ";"  + counter + ";" + df.format((double) time / (double) (1000 * 1000 * 1000)));
		}
	}

	@Override
	public Receive createReceive() {
		return receiveBuilder() //
				.match(NotificationContainer.class, this::handleNotificationContainer)
				.match(NoMoreInput.class, this::sendFinished) //
				.build();
	}

	private void sendFinished(NoMoreInput m) {
		incUtil.allMessagesInserted();
	}
	
	private void handleNotificationContainer(NotificationContainer nc) {
		counter++;
		long tic = System.nanoTime();
		nc.notifications.parallelStream().forEach(this::handleNotification);
		time += System.nanoTime() - tic;
	}
	
	private void handleNotification(Notification notification) {
		switch (notification.getEventType()) {
		case Notification.ADD:
			handleAdd(notification);
			break;
		case Notification.REMOVE:
			handleRemove(notification);
			break;
		case Notification.REMOVING_ADAPTER:
			handleRemoveAdapter(notification);
			break;	
		case Notification.SET:
			handleSet(notification);
			break;
		}
	}

	private void handleAdd(Notification notification) {
		if(notification.getFeature() == null) 
			handleAddedNode(notification.getNewValue());
		else
			handleAddedEdge(notification);
	}

	private void handleAddedNode(Object node) {
		if(node == null) 
			return;
			
		EObject obj = (EObject) node;
		if(type2addConsumer.containsKey(obj.eClass())) {
			type2addConsumer.get(obj.eClass()).accept(node);
		}
	}
	
	private void handleSet(Notification notification) {
		Object feature = notification.getFeature();
		if(feature2setConsumer.containsKey(feature)) {
			feature2setConsumer.get(feature).accept(notification);
		}
	}

	private void handleAddedEdge(Notification notification) {
		//check for self-edges
		if(notification.getNotifier().equals(notification.getNewValue()))
			handleAddedNode(notification.getNewValue());
					
		Object feature = notification.getFeature();
		if(feature2addEdgeConsumer.containsKey(feature)) {
			feature2addEdgeConsumer.get(feature).accept(notification);
		}
	}

	private void handleRemove(Notification notification) {
		Object feature = notification.getFeature();
		if(feature2removeEdgeConsumer.containsKey(feature)) {
			feature2removeEdgeConsumer.get(feature).accept(notification);
		}
	}
	
	private void handleRemoveAdapter(Notification notification) {
		Object node = notification.getNotifier();
		if (node instanceof classDiagram.Clazz) {
			incUtil.newMessage();
			name2actor.get("Clazz_object_SP0").tell(new ObjectDeleted<classDiagram.Clazz>(incUtil, (classDiagram.Clazz) node), getSelf());
		}
		if (node instanceof classDiagram.Clazz) {
			incUtil.newMessage();
			name2actor.get("Clazz_object_SP1").tell(new ObjectDeleted<classDiagram.Clazz>(incUtil, (classDiagram.Clazz) node), getSelf());
		}
		if (node instanceof classDiagram.Clazz) {
			incUtil.newMessage();
			name2actor.get("Clazz_object_SP2").tell(new ObjectDeleted<classDiagram.Clazz>(incUtil, (classDiagram.Clazz) node), getSelf());
		}
		if (node instanceof classDiagram.Method) {
			incUtil.newMessage();
			name2actor.get("Method_object_SP0").tell(new ObjectDeleted<classDiagram.Method>(incUtil, (classDiagram.Method) node), getSelf());
		}
		if (node instanceof classDiagram.Method) {
			incUtil.newMessage();
			name2actor.get("Method_object_SP1").tell(new ObjectDeleted<classDiagram.Method>(incUtil, (classDiagram.Method) node), getSelf());
		}
		if (node instanceof classDiagram.Method) {
			incUtil.newMessage();
			name2actor.get("Method_object_SP2").tell(new ObjectDeleted<classDiagram.Method>(incUtil, (classDiagram.Method) node), getSelf());
		}
		if (node instanceof classDiagram.Attribute) {
			incUtil.newMessage();
			name2actor.get("Attribute_object_SP0").tell(new ObjectDeleted<classDiagram.Attribute>(incUtil, (classDiagram.Attribute) node), getSelf());
		}
		if (node instanceof classDiagram.Attribute) {
			incUtil.newMessage();
			name2actor.get("Attribute_object_SP1").tell(new ObjectDeleted<classDiagram.Attribute>(incUtil, (classDiagram.Attribute) node), getSelf());
		}
		if (node instanceof classDiagram.Attribute) {
			incUtil.newMessage();
			name2actor.get("Attribute_object_SP2").tell(new ObjectDeleted<classDiagram.Attribute>(incUtil, (classDiagram.Attribute) node), getSelf());
		}
	}
}

